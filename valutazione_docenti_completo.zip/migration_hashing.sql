-- ============================================================
--  MIGRATION: HASHING PASSWORD + TABELLA AMMINISTRATORI
--  Da eseguire UNA VOLTA sul database my_valutazionedocentimajo
--  (richiede che migration_multiscuola.sql e
--   migration_chiave_registrazione.sql siano già state eseguite)
-- ============================================================

-- ------------------------------------------------------------
-- 1. PROF: allarga la colonna password per contenere l'hash
--    bcrypt produce stringhe da 60 caratteri, VARCHAR(255) è standard
-- ------------------------------------------------------------
ALTER TABLE `prof`
  MODIFY COLUMN `password` VARCHAR(255) COLLATE utf8mb4_general_ci NOT NULL;

-- ATTENZIONE: le password dei prof esistenti (a, b, c, d) sono in chiaro
-- e non possono essere hashate via SQL. Usa lo script reset_password_prof.php
-- per aggiornarle, oppure ri-registra i prof con la nuova procedura.

-- ------------------------------------------------------------
-- 2. SCUOLA: allarga codice_registrazione per l'hash
-- ------------------------------------------------------------
ALTER TABLE `scuola`
  MODIFY COLUMN `codice_registrazione` VARCHAR(255) NOT NULL DEFAULT '';

-- ATTENZIONE: anche il codice_registrazione esistente è in chiaro.
-- Dopo aver eseguito questa migration, esegui reset_codice_scuola.php
-- per aggiornare il codice con il suo hash.

-- ------------------------------------------------------------
-- 3. AMMINISTRATORI: nuova tabella
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `amministratori` (
  `id`       INT          NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
  `scuola`   INT          NOT NULL COMMENT 'FK → scuola.id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_username_scuola` (`username`, `scuola`),
  CONSTRAINT `fk_admin_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
--  VERIFICA FINALE
-- ============================================================
SELECT 'prof'            AS tabella, COUNT(*) AS righe FROM prof
UNION ALL
SELECT 'amministratori',  COUNT(*) FROM amministratori
UNION ALL
SELECT 'scuola',          COUNT(*) FROM scuola;
