-- ============================================================
--  MIGRATION: ANNO SCOLASTICO SU FEEDBACK E RIASSUNTI_AI
--  Aggiunge la colonna anno_scolastico e un campo sulla scuola
--  per sapere qual è l'anno corrente.
-- ============================================================

-- 1. Aggiunge anno_scolastico corrente alla scuola
ALTER TABLE `scuola`
  ADD COLUMN `anno_scolastico` VARCHAR(9) NOT NULL DEFAULT '2024-2025'
    COMMENT 'Anno scolastico corrente, es. 2024-2025'
    AFTER `codice_registrazione`;

-- 2. Aggiunge anno_scolastico ai feedback
ALTER TABLE `feedback`
  ADD COLUMN `anno_scolastico` VARCHAR(9) NOT NULL DEFAULT '2024-2025'
    COMMENT 'Anno scolastico in cui è stato dato il feedback'
    AFTER `scuola`;

-- 3. Aggiunge anno_scolastico ai riassunti_ai
--    La UNIQUE KEY deve includere anche anno_scolastico
--    perché lo stesso prof può avere riassunti per anni diversi

-- Prima droppa il vecchio unique
ALTER TABLE `riassunti_ai`
  DROP INDEX `uq_riassunto`;

-- Aggiunge la colonna
ALTER TABLE `riassunti_ai`
  ADD COLUMN `anno_scolastico` VARCHAR(9) NOT NULL DEFAULT '2024-2025'
    COMMENT 'Anno scolastico del riassunto'
    AFTER `scuola`;

-- Ricrea unique con anno_scolastico
ALTER TABLE `riassunti_ai`
  ADD UNIQUE KEY `uq_riassunto` (`idProf`, `classe`, `scuola`, `anno_scolastico`);

-- 4. Popola anno_scolastico esistente con il valore di default
UPDATE `feedback`       SET `anno_scolastico` = '2024-2025';
UPDATE `riassunti_ai`   SET `anno_scolastico` = '2024-2025';

-- VERIFICA
SELECT 'feedback'     AS tabella, anno_scolastico, COUNT(*) AS righe FROM feedback     GROUP BY anno_scolastico
UNION ALL
SELECT 'riassunti_ai', anno_scolastico, COUNT(*) FROM riassunti_ai GROUP BY anno_scolastico;
