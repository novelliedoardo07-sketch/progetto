<?php
// get_classi.php  –  restituisce le classi di una scuola in JSON
header('Content-Type: application/json; charset=utf-8');

$idScuola = (int)($_GET['scuola'] ?? 0);

if ($idScuola <= 0) {
    echo json_encode([]);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=my_valutazionedocentimajo;charset=utf8mb4",
        'root', '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $stmt = $pdo->prepare(
        "SELECT classe, sede, n_studenti FROM classi WHERE scuola = ? ORDER BY classe"
    );
    $stmt->execute([$idScuola]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([]);
}
