-- ============================================================
--  MIGRATION: TABELLA PASSWORD_RESET_TOKENS
--  Salva i token per il reset password dei professori
-- ============================================================

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_prof`    INT          NOT NULL,
  `scuola`     INT          NOT NULL,
  `token`      VARCHAR(64)  NOT NULL,
  `scade_il`   DATETIME     NOT NULL COMMENT 'Token valido 1 ora',
  `usato`      TINYINT(1)   NOT NULL DEFAULT 0,
  `creato_il`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token` (`token`),
  CONSTRAINT `fk_prt_prof`
    FOREIGN KEY (`id_prof`) REFERENCES `prof` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_prt_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- VERIFICA
SELECT 'password_reset_tokens' AS tabella, COUNT(*) AS righe FROM password_reset_tokens;
