<?php
// registra_scuola.php  –  endpoint multipart/form-data chiamato da registra_scuola.html
// Crea: scuola (con logo), amministratore, classi, studenti con credenziali casuali

header('Content-Type: application/json; charset=utf-8');

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita.']);
    exit;
}

// ── Leggi campi POST ──────────────────────────────────────────
$nome          = trim($_POST['nome']          ?? '');
$citta         = trim($_POST['citta']         ?? '');
$contatti      = trim($_POST['contatti']      ?? '');
$adminUsername = trim($_POST['adminUsername'] ?? '');
$adminPassword = trim($_POST['adminPassword'] ?? '');
$codiceReg     = trim($_POST['codiceReg']     ?? '');
$classiJson    = $_POST['classi']             ?? '[]';
$classi        = json_decode($classiJson, true) ?? [];

// Validazione
if (!$nome || !$citta || !$adminUsername || !$adminPassword || !$codiceReg) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Campi obbligatori mancanti.']);
    exit;
}
if (empty($classi)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Nessuna classe fornita.']);
    exit;
}
foreach ($classi as $i => $cl) {
    if (empty($cl['classe']) || empty($cl['sede']) || empty($cl['n_studenti']) || (int)$cl['n_studenti'] <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => "Classe alla riga " . ($i+1) . " non valida."]);
        exit;
    }
}

// ── Upload logo ───────────────────────────────────────────────
$logoFilename = 'logo.png'; // default

if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
    $file     = $_FILES['logo'];
    $maxSize  = 2 * 1024 * 1024; // 2MB

    if ($file['size'] > $maxSize) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Il logo supera i 2MB.']);
        exit;
    }

    // Verifica tipo MIME reale (non solo l'estensione dichiarata)
    $finfo    = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    $allowed  = ['image/png' => 'png', 'image/jpeg' => 'jpg'];

    if (!isset($allowed[$mimeType])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Formato logo non supportato. Usa PNG o JPG.']);
        exit;
    }

    // Nome file: logo_<nome_scuola_slug>.<ext>
    $slug         = preg_replace('/[^a-z0-9]+/', '_', strtolower($nome));
    $ext          = $allowed[$mimeType];
    $logoFilename = 'logo_' . $slug . '.' . $ext;
    $destPath     = __DIR__ . '/' . $logoFilename;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Impossibile salvare il logo sul server.']);
        exit;
    }
}

// ── Generazione credenziali casuali ───────────────────────────
define('CHARS', 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789');

function randomStr(int $len): string {
    $chars  = CHARS;
    $result = '';
    $max    = strlen($chars) - 1;
    for ($i = 0; $i < $len; $i++) {
        $result .= $chars[random_int(0, $max)];
    }
    return $result;
}

function generaCredenziali(int $totale): array {
    $credenziali = [];
    $usedUser    = [];
    $usedPass    = [];
    $tentativi   = 0;

    while (count($credenziali) < $totale && $tentativi < $totale * 20) {
        $tentativi++;
        $u = randomStr(3);
        $p = randomStr(3);
        if (isset($usedUser[$u]) || isset($usedPass[$p])) continue;
        $usedUser[$u] = true;
        $usedPass[$p] = true;
        $credenziali[] = ['username' => $u, 'password' => $p];
    }

    // Fallback a 4 caratteri se le combinazioni a 3 si esauriscono
    while (count($credenziali) < $totale) {
        $u = randomStr(4);
        $p = randomStr(4);
        if (isset($usedUser[$u])) continue;
        $usedUser[$u] = true;
        $credenziali[] = ['username' => $u, 'password' => $p];
    }

    return $credenziali;
}

$totStudenti = array_sum(array_column($classi, 'n_studenti'));

// ── Salva richiesta in attesa di approvazione ─────────────────
$token      = bin2hex(random_bytes(32)); // token univoco 64 caratteri
$hashCodice = password_hash($codiceReg, PASSWORD_BCRYPT);
$hashAdmin  = password_hash($adminPassword, PASSWORD_BCRYPT);
$classiJson = json_encode($classi);

// Email super admin — CAMBIA con la tua email
$superAdminEmail = 'novelli.edoardo07@majorana.org';
$baseUrl         = 'https://valutazionedocentimajo.altervista.org';

try {
    $pdo->prepare(
        "INSERT INTO richieste_scuola
         (nome, citta, logo, contatti, admin_username, admin_password, codice_reg, classi_json, token)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $nome, $citta, $logoFilename, $contatti,
        $adminUsername, $hashAdmin, $hashCodice,
        $classiJson, $token
    ]);

    // ── Manda email al super admin ────────────────────────────
    $linkApprova  = "{$baseUrl}/approva_scuola.php?token={$token}&azione=approva";
    $linkRifiuta  = "{$baseUrl}/approva_scuola.php?token={$token}&azione=rifiuta";

    $oggetto = "Nuova richiesta registrazione scuola: {$nome}";
    $corpo   = "È arrivata una nuova richiesta di registrazione scuola.

"
             . "Scuola:  {$nome} ({$citta})
"
             . "Admin:   {$adminUsername}
"
             . "Classi:  " . count($classi) . "
"
             . "Studenti: {$totStudenti}

"
             . "APPROVA: {$linkApprova}

"
             . "RIFIUTA: {$linkRifiuta}

"
             . "Puoi anche gestirla dal pannello Super Admin.
";

    $headers  = "From: noreply@valutazionedocentimajo.altervista.org
";
    $headers .= "Content-Type: text/plain; charset=UTF-8
";

    mail($superAdminEmail, $oggetto, $corpo, $headers);

    echo json_encode([
        'success'    => true,
        'pending'    => true,
        'nomeScuola' => $nome,
        'nClassi'    => count($classi),
        'nStudenti'  => $totStudenti,
    ]);

} catch (PDOException $e) {
    if ($logoFilename !== 'logo.png' && file_exists(__DIR__ . '/' . $logoFilename)) {
        unlink(__DIR__ . '/' . $logoFilename);
    }
    http_response_code(500);
    $msg = 'Errore durante il salvataggio della richiesta.';
    if (str_contains($e->getMessage(), 'Duplicate')) {
        $msg = 'Richiesta già inviata per questa scuola.';
    }
    echo json_encode(['success' => false, 'error' => $msg]);
}
