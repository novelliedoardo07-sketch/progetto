<?php
require_once 'auth_check.php';
requireRuolo('admin');

$idScuola = (int)$_SESSION['scuola'];
require_once 'db.php';

$msg   = '';
$error = '';

// ── POST ACTIONS ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── PROF: aggiungi ────────────────────────────────────────
    if ($action === 'add_prof') {
        $nome     = trim($_POST['nome'] ?? '');
        $cognome  = trim($_POST['cognome'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $classi   = $_POST['classi'] ?? [];

        if (!$nome || !$cognome || !$username || !$password) {
            $error = 'Compila tutti i campi obbligatori.';
        } else {
            $chk = $pdo->prepare("SELECT id FROM prof WHERE username = ? AND scuola = ?");
            $chk->execute([$username, $idScuola]);
            if ($chk->fetch()) {
                $error = 'Username già in uso.';
            } else {
                $pdo->beginTransaction();
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO prof (nome, cognome, mail, username, password, scuola) VALUES (?, ?, '', ?, ?, ?)");
                $stmt->execute([$nome, $cognome, $username, $hash, $idScuola]);
                $idProf = $pdo->lastInsertId();
                if (!empty($classi)) {
                    $ins = $pdo->prepare("INSERT INTO insegna (id, classe, scuola) VALUES (?, ?, ?)");
                    foreach ($classi as $cl) {
                        $ins->execute([$idProf, trim($cl), $idScuola]);
                    }
                }
                $pdo->commit();
                $msg = "Professore «{$username}» aggiunto con successo.";
            }
        }

    // ── PROF: elimina ─────────────────────────────────────────
    } elseif ($action === 'del_prof') {
        $idProf = (int)($_POST['id_prof'] ?? 0);
        if ($idProf) {
            $chk = $pdo->prepare("SELECT id FROM prof WHERE id = ? AND scuola = ?");
            $chk->execute([$idProf, $idScuola]);
            if ($chk->fetch()) {
                $pdo->prepare("DELETE FROM prof WHERE id = ?")->execute([$idProf]);
                $msg = 'Professore eliminato.';
            } else {
                $error = 'Professore non trovato.';
            }
        }

    // ── PROF: reset password ──────────────────────────────────
    } elseif ($action === 'reset_prof_pass') {
        $idProf    = (int)($_POST['id_prof'] ?? 0);
        $nuovaPass = trim($_POST['nuova_password'] ?? '');
        if ($idProf && $nuovaPass) {
            $chk = $pdo->prepare("SELECT id FROM prof WHERE id = ? AND scuola = ?");
            $chk->execute([$idProf, $idScuola]);
            if ($chk->fetch()) {
                $hash = password_hash($nuovaPass, PASSWORD_BCRYPT);
                $pdo->prepare("UPDATE prof SET password = ? WHERE id = ?")->execute([$hash, $idProf]);
                $msg = 'Password professore aggiornata.';
            } else {
                $error = 'Professore non trovato.';
            }
        }

    // ── CLASSE: aggiungi ──────────────────────────────────────
    } elseif ($action === 'add_classe') {
        $classe    = strtoupper(trim($_POST['classe'] ?? ''));
        $sede      = strtoupper(trim($_POST['sede'] ?? 'SEDE'));
        $nStudenti = (int)($_POST['n_studenti'] ?? 0);
        if ($classe && $nStudenti > 0) {
            $chk = $pdo->prepare("SELECT classe FROM classi WHERE classe = ? AND scuola = ?");
            $chk->execute([$classe, $idScuola]);
            if ($chk->fetch()) {
                $error = 'Classe già esistente.';
            } else {
                $pdo->prepare("INSERT INTO classi (classe, sede, n_studenti, scuola) VALUES (?, ?, ?, ?)")
                    ->execute([$classe, $sede, $nStudenti, $idScuola]);
                $msg = "Classe «{$classe}» aggiunta.";
            }
        } else {
            $error = 'Inserisci nome classe e numero studenti.';
        }

    // ── CLASSI: import bulk + genera studenti ────────────────
    } elseif ($action === 'import_classi') {
        $righe    = json_decode($_POST['righe'] ?? '[]', true) ?? [];
        $inserite = 0; $saltate = 0; $totStudenti = 0; $errori = [];

        // Funzione generazione credenziali casuali (stessa logica di registra_scuola.php)
        $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
        $randomStr = function(int $len) use ($chars): string {
            $result = ''; $max = strlen($chars) - 1;
            for ($i = 0; $i < $len; $i++) $result .= $chars[random_int(0, $max)];
            return $result;
        };

        if (!empty($righe)) {
            // Calcola totale studenti da generare (solo classi nuove)
            $chk     = $pdo->prepare("SELECT classe FROM classi WHERE classe = ? AND scuola = ?");
            $insC    = $pdo->prepare("INSERT INTO classi (classe, sede, n_studenti, scuola) VALUES (?, ?, ?, ?)");
            $insS    = $pdo->prepare("INSERT INTO studenti (username, password, IsUsed, classe, scuola) VALUES (?, ?, 0, ?, ?)");
            // Recupera tutti gli username studenti esistenti per questa scuola (per evitare duplicati)
            $usedU   = $pdo->prepare("SELECT username FROM studenti WHERE scuola = ?");
            $usedU->execute([$idScuola]);
            $usedUser = array_flip($usedU->fetchAll(PDO::FETCH_COLUMN));

            $pdo->beginTransaction();
            foreach ($righe as $i => $r) {
                $cl = strtoupper(trim($r['classe'] ?? ''));
                $se = strtoupper(trim($r['sede']   ?? 'SEDE'));
                $ns = (int)($r['n_studenti'] ?? 0);
                if (!$cl || $ns <= 0) { $errori[] = "Riga ".($i+1)." non valida."; continue; }
                $chk->execute([$cl, $idScuola]);
                if ($chk->fetch()) { $saltate++; continue; }

                // Inserisci classe
                $insC->execute([$cl, $se, $ns, $idScuola]);
                $inserite++;
                $totStudenti += $ns;

                // Genera studenti con credenziali univoche
                $generati = 0;
                $tentativi = 0;
                while ($generati < $ns && $tentativi < $ns * 20) {
                    $tentativi++;
                    $u = $randomStr(3);
                    if (isset($usedUser[$u])) continue;
                    $p = $randomStr(3);
                    $usedUser[$u] = true;
                    $insS->execute([$u, $p, $cl, $idScuola]);
                    $generati++;
                }
                // Fallback a 4 caratteri se le combinazioni a 3 si esauriscono
                while ($generati < $ns) {
                    $u = $randomStr(4);
                    if (isset($usedUser[$u])) continue;
                    $p = $randomStr(4);
                    $usedUser[$u] = true;
                    $insS->execute([$u, $p, $cl, $idScuola]);
                    $generati++;
                }
            }
            $pdo->commit();
            $msg = "Import completato: {$inserite} classi aggiunte, {$totStudenti} studenti generati" .
                   ($saltate ? " ({$saltate} classi già esistenti saltate)" : "") . ".";
            if ($errori) $msg .= " Errori: " . implode(" ", $errori);
        } else {
            $error = 'Nessuna riga ricevuta. Riprova.';
        }

    // ── CLASSE: elimina ───────────────────────────────────────
    } elseif ($action === 'del_classe') {
        $classe = trim($_POST['classe'] ?? '');
        if ($classe) {
            $pdo->prepare("DELETE FROM classi WHERE classe = ? AND scuola = ?")->execute([$classe, $idScuola]);
            $msg = "Classe «{$classe}» eliminata.";
        }

    // ── STUDENTE: reset IsUsed singolo ────────────────────────
    } elseif ($action === 'reset_isused') {
        $idStudente = (int)($_POST['id_studente'] ?? 0);
        if ($idStudente) {
            $pdo->prepare("UPDATE studenti SET IsUsed = 0 WHERE id = ? AND scuola = ?")->execute([$idStudente, $idScuola]);
            $msg = 'Studente resettato: può votare di nuovo.';
        }

    // ── STUDENTE: reset IsUsed tutta classe ───────────────────
    } elseif ($action === 'reset_classe_isused') {
        $classe = trim($_POST['classe'] ?? '');
        if ($classe) {
            $pdo->prepare("UPDATE studenti SET IsUsed = 0 WHERE classe = ? AND scuola = ?")->execute([$classe, $idScuola]);
            $msg = "Tutti gli studenti della classe «{$classe}» resettati.";
        }

    // ── STUDENTE: aggiungi ────────────────────────────────────
    } elseif ($action === 'add_studente') {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $classe   = trim($_POST['classe'] ?? '');
        if ($username && $password && $classe) {
            $chk = $pdo->prepare("SELECT id FROM studenti WHERE username = ? AND scuola = ?");
            $chk->execute([$username, $idScuola]);
            if ($chk->fetch()) {
                $error = 'Username già in uso.';
            } else {
                $pdo->prepare("INSERT INTO studenti (username, password, IsUsed, classe, scuola) VALUES (?, ?, 0, ?, ?)")
                    ->execute([$username, $password, $classe, $idScuola]);
                $msg = "Studente «{$username}» aggiunto.";
            }
        } else {
            $error = 'Compila tutti i campi.';
        }

    // ── SCUOLA: cambio anno scolastico ───────────────────────
    } elseif ($action === 'update_anno') {
        $nuovoAnno = trim($_POST['anno_scolastico'] ?? '');
        if (preg_match('/^\d{4}-\d{4}$/', $nuovoAnno)) {
            $pdo->beginTransaction();

            // Aggiorna anno scuola
            $pdo->prepare("UPDATE scuola SET anno_scolastico = ? WHERE id = ?")->execute([$nuovoAnno, $idScuola]);

            // Rigenera credenziali studenti e resetta IsUsed
            $studenti = $pdo->prepare("SELECT id FROM studenti WHERE scuola = ?");
            $studenti->execute([$idScuola]);
            $updStud = $pdo->prepare("UPDATE studenti SET username = ?, password = ?, IsUsed = 0 WHERE id = ?");

            $usedUser = []; $usedPass = [];
            $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
            $max   = strlen($chars) - 1;
            $randomStr = function(int $len) use ($chars, $max): string {
                $r = '';
                for ($i = 0; $i < $len; $i++) $r .= $chars[random_int(0, $max)];
                return $r;
            };

            foreach ($studenti->fetchAll(PDO::FETCH_ASSOC) as $s) {
                do { $u = $randomStr(3); } while (isset($usedUser[$u]));
                do { $p = $randomStr(3); } while (isset($usedPass[$p]));
                $usedUser[$u] = true; $usedPass[$p] = true;
                $updStud->execute([$u, $p, $s['id']]);
            }

            $pdo->commit();
            $nStudenti = count($usedUser);
            // Aggiorna la variabile $scuola in memoria per riflettere il nuovo anno
            $scuola['anno_scolastico'] = $nuovoAnno;
            $msg = "Anno aggiornato a {$nuovoAnno}. Credenziali rigenerate per {$nStudenti} studenti e IsUsed resettato.";
        } else {
            $error = 'Formato non valido. Usa es. 2025-2026.';
        }

    // ── SCUOLA: cambio codice registrazione ───────────────────
    } elseif ($action === 'update_codice') {
        $nuovoCodice = trim($_POST['codice'] ?? '');
        if ($nuovoCodice) {
            $hash = password_hash($nuovoCodice, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE scuola SET codice_registrazione = ? WHERE id = ?")->execute([$hash, $idScuola]);
            $msg = 'Codice di registrazione aggiornato.';
        } else {
            $error = 'Il codice non può essere vuoto.';
        }
    }
}

// ── DATI PER LA VISTA ─────────────────────────────────────────
$profList = $pdo->prepare(
    "SELECT p.id, p.nome, p.cognome, p.username,
            GROUP_CONCAT(i.classe ORDER BY i.classe SEPARATOR ', ') AS classi
     FROM prof p
     LEFT JOIN insegna i ON i.id = p.id AND i.scuola = p.scuola
     WHERE p.scuola = ?
     GROUP BY p.id ORDER BY p.cognome, p.nome"
);
$profList->execute([$idScuola]);
$profs = $profList->fetchAll(PDO::FETCH_ASSOC);

$classiList = $pdo->prepare("SELECT classe, sede, n_studenti FROM classi WHERE scuola = ? ORDER BY classe");
$classiList->execute([$idScuola]);
$classi = $classiList->fetchAll(PDO::FETCH_ASSOC);

$classeSelezionata = trim($_GET['classe'] ?? '');
$studenti = [];
if ($classeSelezionata) {
    $stmtS = $pdo->prepare("SELECT id, username, IsUsed FROM studenti WHERE classe = ? AND scuola = ? ORDER BY username");
    $stmtS->execute([$classeSelezionata, $idScuola]);
    $studenti = $stmtS->fetchAll(PDO::FETCH_ASSOC);
}

// Determina quale tab mostrare dopo un POST
$activeTab = 'prof';
if (!empty($_POST['action'])) {
    $a = $_POST['action'];
    if (str_contains($a, 'classe') || $a === 'import_classi') $activeTab = 'classi';
    elseif (str_contains($a, 'stud') || str_contains($a, 'isused')) $activeTab = 'studenti';
    elseif ($a === 'update_codice' || $a === 'update_anno') $activeTab = 'scuola';
}
if (isset($_GET['tab'])) $activeTab = $_GET['tab'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin – <?= htmlspecialchars($scuola['nome']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        .admin-wrap { max-width: 1100px; margin: 0 auto; padding: 0 20px 60px; }

        /* TABS */
        .tabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 28px; }
        .tab-btn {
            font-family: 'Barlow Condensed', sans-serif;
            font-size: 15px; font-weight: 700; letter-spacing: .5px;
            padding: 9px 22px; border-radius: 100px;
            border: 2px solid var(--grigio-brd);
            background: white; color: #888; cursor: pointer;
            transition: all .2s;
        }
        .tab-btn:hover { border-color: var(--blu); color: var(--blu); }
        .tab-btn.active { background: var(--blu); border-color: var(--blu); color: white; box-shadow: 0 4px 14px rgba(0,0,205,.25); }
        .tab-panel { display: none; }
        .tab-panel.active { display: block; }

        /* CARDS */
        .card { background: white; border: 1px solid var(--grigio-brd); border-radius: var(--radius-lg); padding: 24px 28px; box-shadow: var(--shadow-md); margin-bottom: 22px; }
        .card h3 { font-family: 'Barlow Condensed', sans-serif; font-size: 20px; font-weight: 800; color: var(--blu); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 2px solid var(--blu-light); }

        /* FORM INLINE */
        .form-row { display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end; }
        .form-row input, .form-row select { flex: 1; min-width: 140px; margin: 0; padding: 9px 13px; font-size: 14px; }
        .form-row button { width: auto; padding: 9px 22px; font-size: 14px; margin: 0; flex-shrink: 0; }

        /* TABELLA */
        .data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .data-table th { text-align: left; padding: 10px 12px; background: var(--grigio-bg); color: #555; font-family: 'Barlow Condensed', sans-serif; font-size: 13px; font-weight: 700; letter-spacing: .5px; text-transform: uppercase; border-bottom: 2px solid var(--grigio-brd); }
        .data-table td { padding: 10px 12px; border-bottom: 1px solid var(--grigio-brd); vertical-align: middle; }
        .data-table tr:last-child td { border-bottom: none; }
        .data-table tr:hover td { background: var(--grigio-bg); }

        /* BADGES */
        .badge-ok  { background: #dcfce7; color: #166534; font-size: 12px; font-weight: 700; padding: 3px 10px; border-radius: 100px; }
        .badge-no  { background: #fee2e2; color: #991b1b; font-size: 12px; font-weight: 700; padding: 3px 10px; border-radius: 100px; }

        /* BUTTONS */
        .btn-sm { width: auto; padding: 5px 14px; font-size: 13px; margin: 0; }
        .btn-danger { background: #dc2626; }
        .btn-danger:hover { background: #b91c1c; }
        .btn-warn { background: #d97706; }
        .btn-warn:hover { background: #b45309; }

        /* MESSAGGI */
        .msg-ok  { background: #dcfce7; color: #166534; border: 1px solid #86efac; border-radius: var(--radius-sm); padding: 12px 16px; margin-bottom: 20px; font-weight: 600; }
        .msg-err { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: var(--radius-sm); padding: 12px 16px; margin-bottom: 20px; font-weight: 600; }

        /* MODAL */
        .modal-bg { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 1000; align-items: center; justify-content: center; }
        .modal-bg.open { display: flex; }
        .modal { background: white; border-radius: var(--radius-lg); padding: 30px; max-width: 440px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,.3); }
        .modal h4 { font-family: 'Barlow Condensed', sans-serif; font-size: 20px; font-weight: 800; color: var(--blu); margin-bottom: 16px; }
        .modal input { margin-bottom: 12px; }

        /* CHECKBOXES CLASSI */
        .classi-check-grid { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }
        .classi-check-grid label { display: flex; align-items: center; gap: 5px; font-size: 13px; background: var(--grigio-bg); border: 1px solid var(--grigio-brd); border-radius: 6px; padding: 4px 10px; cursor: pointer; transition: background .15s; }
        .classi-check-grid label:hover { background: var(--blu-light); }

        /* FILTRO STUDENTI */
        .classe-filter { display: flex; gap: 10px; align-items: center; margin-bottom: 20px; flex-wrap: wrap; }
        .classe-filter select { margin: 0; width: auto; min-width: 200px; }
        .classe-filter button { width: auto; padding: 9px 20px; margin: 0; }

        @media(max-width:640px) { .form-row { flex-direction: column; } .form-row input, .form-row select { min-width: 0; } }

        /* CSV IMPORT */
        .import-tabs { display:flex; gap:6px; margin-bottom:14px; }
        .import-tab { font-family:'Barlow Condensed',sans-serif; font-size:13px; font-weight:700; padding:6px 16px; border-radius:100px; border:2px solid var(--grigio-brd); background:white; color:#888; cursor:pointer; transition:all .2s; }
        .import-tab.active { background:var(--blu); border-color:var(--blu); color:white; }
        .import-tab-panel { display:none; }
        .import-tab-panel.active { display:block; }
        .csv-drop { border:2px dashed var(--grigio-brd); border-radius:var(--radius-md); padding:22px; text-align:center; cursor:pointer; background:var(--grigio-bg); transition:border-color .2s,background .2s; }
        .csv-drop:hover, .csv-drop.drag-over { border-color:var(--blu); background:var(--blu-light); }
        .csv-drop input[type="file"] { display:none; }
        .csv-drop p { font-size:13px; color:#666; margin:4px 0 0; }
        #csvImportName { margin-top:8px; font-size:13px; font-weight:600; color:var(--blu); min-height:18px; }
        .bulk-area { font-family:monospace; font-size:13px; min-height:110px; }
        .import-preview { margin-top:14px; font-size:13px; }
        .import-preview table { width:100%; border-collapse:collapse; }
        .import-preview th { background:var(--grigio-bg); padding:6px 10px; text-align:left; font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.4px; border-bottom:2px solid var(--grigio-brd); }
        .import-preview td { padding:6px 10px; border-bottom:1px solid var(--grigio-brd); }
        .import-preview tr:last-child td { border-bottom:none; }
        .badge-sede-sm { font-size:11px; font-weight:700; background:var(--blu-light); color:var(--blu); border-radius:4px; padding:2px 6px; }
    </style>
</head>
<body>

    <img src="<?= htmlspecialchars($scuola['logo']) ?>" alt="logo" id="logo1">
    <button id="homeBtn" onclick="window.location.href='logout.php'">Esci</button>

    <header class="page-hero">
        <h1>Dashboard Amministratore</h1>
        <h2><?= htmlspecialchars($scuola['nome']) ?> – <?= htmlspecialchars($scuola['citta']) ?></h2>
    </header>

    <div class="admin-wrap">

        <?php if ($msg):  ?><div class="msg-ok">✅ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg-err">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

        <div class="tabs">
            <button class="tab-btn <?= $activeTab === 'prof'     ? 'active' : '' ?>" onclick="showTab('prof',this)">👨‍🏫 Professori</button>
            <button class="tab-btn <?= $activeTab === 'classi'   ? 'active' : '' ?>" onclick="showTab('classi',this)">📋 Classi</button>
            <button class="tab-btn <?= $activeTab === 'studenti' ? 'active' : '' ?>" onclick="showTab('studenti',this)">🎒 Studenti</button>
            <button class="tab-btn <?= $activeTab === 'scuola'   ? 'active' : '' ?>" onclick="showTab('scuola',this)">🏫 Scuola</button>
        </div>

        <!-- ══ TAB PROF ══════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab === 'prof' ? 'active' : '' ?>" id="tab-prof">

            <div class="card">
                <h3>➕ Aggiungi Professore</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_prof">
                    <div class="form-row">
                        <input type="text" name="nome" placeholder="Nome *" required>
                        <input type="text" name="cognome" placeholder="Cognome *" required>
                        <input type="text" name="username" placeholder="Username *" required>
                        <input type="password" name="password" placeholder="Password *" required>
                    </div>
                    <div style="margin-top:14px;">
                        <label style="font-size:13px; font-weight:600; color:#555; display:block; margin-bottom:6px;">Classi assegnate</label>
                        <div class="classi-check-grid">
                            <?php foreach ($classi as $cl): ?>
                                <label>
                                    <input type="checkbox" name="classi[]" value="<?= htmlspecialchars($cl['classe']) ?>">
                                    <span><?= htmlspecialchars($cl['classe']) ?> <?= htmlspecialchars($cl['sede']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top:16px;">
                        <button type="submit">Aggiungi Professore</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>📋 Professori registrati (<?= count($profs) ?>)</h3>
                <?php if (empty($profs)): ?>
                    <p style="color:#888;">Nessun professore registrato.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Nome</th><th>Username</th><th>Classi</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($profs as $p): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['cognome'] . ' ' . $p['nome']) ?></td>
                            <td><code><?= htmlspecialchars($p['username']) ?></code></td>
                            <td style="font-size:13px; color:#666;"><?= htmlspecialchars($p['classi'] ?? '—') ?></td>
                            <td style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button class="btn-sm btn-warn" onclick="openResetPass(<?= $p['id'] ?>, '<?= htmlspecialchars($p['username'], ENT_QUOTES) ?>')">🔑 Reset pw</button>
                                <form method="POST" onsubmit="return confirm('Eliminare il prof <?= htmlspecialchars($p['username'], ENT_QUOTES) ?>?');" style="display:inline">
                                    <input type="hidden" name="action" value="del_prof">
                                    <input type="hidden" name="id_prof" value="<?= $p['id'] ?>">
                                    <button type="submit" class="btn-sm btn-danger">🗑 Elimina</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB CLASSI ════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab === 'classi' ? 'active' : '' ?>" id="tab-classi">

            <div class="card">
                <h3>➕ Aggiungi Classe</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_classe">
                    <div class="form-row">
                        <input type="text" name="classe" placeholder="Codice classe (es. 3AII) *" required style="text-transform:uppercase;">
                        <input type="text" name="sede" placeholder="Sede (es. EUROPA)" value="SEDE">
                        <input type="number" name="n_studenti" placeholder="N° studenti *" min="1" required>
                        <button type="submit">Aggiungi</button>
                    </div>
                </form>
            </div>

            <div class="card" id="cardImportClassi">
                <h3>📤 Importa Classi da CSV</h3>
                <div class="import-tabs">
                    <button class="import-tab active" onclick="switchImportTab('csv',this)">📄 File CSV</button>
                    <button class="import-tab" onclick="switchImportTab('bulk',this)">✏️ Testo Bulk</button>
                </div>
                <div class="import-tab-panel active" id="ipanel-csv">
                    <div class="csv-drop" id="csvDropAdmin" onclick="document.getElementById('csvImportFile').click()">
                        <span style="font-size:28px;">📂</span>
                        <p><strong>Clicca o trascina</strong> il file CSV qui</p>
                        <p>Formato: <code>classe;sede;n_studenti</code> — una riga per classe</p>
                        <input type="file" id="csvImportFile" accept=".csv,.txt">
                    </div>
                    <div id="csvImportName"></div>
                </div>
                <div class="import-tab-panel" id="ipanel-bulk">
                    <textarea class="bulk-area" id="bulkImportInput" placeholder="3AII;EUROPA;24&#10;3BII;EUROPA;22&#10;5AEI;SEDE;23"></textarea>
                    <p style="font-size:12px;color:#888;margin-top:4px;">Formato: <code>CLASSE;SEDE;N_STUDENTI</code> — una riga per classe</p>
                </div>
                <div class="import-preview" id="importPreview" style="display:none;">
                    <div style="font-size:13px;font-weight:600;color:#555;margin-bottom:8px;">
                        Anteprima: <span id="importCount">0</span> classi trovate
                    </div>
                    <div style="max-height:220px;overflow-y:auto;border:1px solid var(--grigio-brd);border-radius:var(--radius-sm);">
                        <table><thead><tr><th>Classe</th><th>Sede</th><th>N° studenti</th></tr></thead>
                        <tbody id="importPreviewBody"></tbody></table>
                    </div>
                    <form method="POST" id="importForm" style="margin-top:12px;">
                        <input type="hidden" name="action" value="import_classi">
                        <input type="hidden" name="righe" id="importRighe">
                        <div class="form-row">
                            <button type="submit">📥 Importa nel database</button>
                            <button type="button" onclick="resetImport()" style="background:#888;width:auto;padding:9px 18px;margin:0;">✕ Annulla</button>
                        </div>
                    </form>
                </div>
                <div id="importParseBtn" style="margin-top:12px; display:none;">
                    <button type="button" onclick="parseImport()" style="width:auto;padding:9px 22px;">👁 Anteprima</button>
                </div>
            </div>

            <div class="card">
                <h3>📋 Classi registrate (<?= count($classi) ?>)</h3>
                <?php if (empty($classi)): ?>
                    <p style="color:#888;">Nessuna classe registrata.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Classe</th><th>Sede</th><th>N° studenti</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($classi as $cl): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($cl['classe']) ?></strong></td>
                            <td><?= htmlspecialchars($cl['sede']) ?></td>
                            <td><?= $cl['n_studenti'] ?></td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Eliminare la classe <?= htmlspecialchars($cl['classe'], ENT_QUOTES) ?>? Verranno eliminati anche tutti i dati collegati.');" style="display:inline">
                                    <input type="hidden" name="action" value="del_classe">
                                    <input type="hidden" name="classe" value="<?= htmlspecialchars($cl['classe']) ?>">
                                    <button type="submit" class="btn-sm btn-danger">🗑 Elimina</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB STUDENTI ══════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab === 'studenti' ? 'active' : '' ?>" id="tab-studenti">

            <div class="card">
                <h3>➕ Aggiungi Studente</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_studente">
                    <div class="form-row">
                        <input type="text" name="username" placeholder="Username * (max 5 car.)" required maxlength="5">
                        <input type="text" name="password" placeholder="Password *" required>
                        <select name="classe" required>
                            <option value="">— Classe —</option>
                            <?php foreach ($classi as $cl): ?>
                                <option value="<?= htmlspecialchars($cl['classe']) ?>"><?= htmlspecialchars($cl['classe']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit">Aggiungi</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>🔍 Gestione Studenti per Classe</h3>
                <form method="GET" action="dashboard_admin.php">
                    <div class="classe-filter">
                        <select name="classe">
                            <option value="">— Seleziona classe —</option>
                            <?php foreach ($classi as $cl): ?>
                                <option value="<?= htmlspecialchars($cl['classe']) ?>"
                                    <?= $classeSelezionata === $cl['classe'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cl['classe']) ?> (<?= htmlspecialchars($cl['sede']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit">Carica</button>
                        <?php if ($classeSelezionata): ?>
                        <form method="POST" onsubmit="return confirm('Resettare tutti gli studenti della classe <?= htmlspecialchars($classeSelezionata, ENT_QUOTES) ?>?');" style="display:contents">
                            <input type="hidden" name="action" value="reset_classe_isused">
                            <input type="hidden" name="classe" value="<?= htmlspecialchars($classeSelezionata) ?>">
                            <button type="submit" class="btn-warn">🔄 Reset tutta la classe</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </form>

                <?php if ($classeSelezionata && !empty($studenti)): ?>
                <table class="data-table">
                    <thead><tr><th>Username</th><th>Ha votato</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($studenti as $s): ?>
                        <tr>
                            <td><code><?= htmlspecialchars($s['username']) ?></code></td>
                            <td><?= $s['IsUsed'] ? '<span class="badge-no">✓ Sì</span>' : '<span class="badge-ok">No</span>' ?></td>
                            <td>
                                <?php if ($s['IsUsed']): ?>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="reset_isused">
                                    <input type="hidden" name="id_studente" value="<?= $s['id'] ?>">
                                    <button type="submit" class="btn-sm btn-warn">🔄 Reset</button>
                                </form>
                                <?php else: ?>
                                    <span style="color:#aaa; font-size:13px;">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php elseif ($classeSelezionata): ?>
                    <p style="color:#888; margin-top:10px;">Nessuno studente in questa classe.</p>
                <?php else: ?>
                    <p style="color:#aaa; font-size:14px; margin-top:10px;">Seleziona una classe per vedere gli studenti.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB SCUOLA ════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab === 'scuola' ? 'active' : '' ?>" id="tab-scuola">
            <div class="card">
                <h3>📅 Anno Scolastico Corrente</h3>
                <p style="font-size:14px; color:#666; margin-bottom:16px;">
                    L'anno scolastico viene salvato insieme ad ogni feedback e riassunto AI.<br>
                    Cambiarlo all'inizio del nuovo anno permette ai prof di confrontare i risultati nel tempo.
                </p>
                <form method="POST">
                    <input type="hidden" name="action" value="update_anno">
                    <div class="form-row">
                        <input type="text" name="anno_scolastico"
                               placeholder="Es. 2025-2026"
                               pattern="\d{4}-\d{4}"
                               value="<?= htmlspecialchars($scuola['anno_scolastico'] ?? '2024-2025') ?>"
                               required>
                        <button type="submit">Aggiorna Anno</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>🔑 Codice di Registrazione Professori</h3>
                <p style="font-size:14px; color:#666; margin-bottom:16px;">
                    Questo codice viene richiesto ai professori durante la registrazione.<br>
                    Cambiarlo non invalida gli account già esistenti.
                </p>
                <form method="POST">
                    <input type="hidden" name="action" value="update_codice">
                    <div class="form-row">
                        <input type="text" name="codice" placeholder="Nuovo codice di registrazione *" required>
                        <button type="submit">Aggiorna Codice</button>
                    </div>
                </form>
            </div>
        </div>

    </div><!-- /admin-wrap -->

    <!-- MODAL RESET PASSWORD PROF -->
    <div class="modal-bg" id="modalResetPass">
        <div class="modal">
            <h4>🔑 Reset Password Professore</h4>
            <p id="modalProfName" style="font-size:14px; color:#666; margin-bottom:14px;"></p>
            <form method="POST">
                <input type="hidden" name="action" value="reset_prof_pass">
                <input type="hidden" name="id_prof" id="modalProfId">
                <input type="password" name="nuova_password" placeholder="Nuova password *" required>
                <div class="form-row">
                    <button type="submit">Salva</button>
                    <button type="button" onclick="closeModal()" style="background:#888;">Annulla</button>
                </div>
            </form>
        </div>
    </div>

    <div id="contatti">
        <h2>I nostri contatti</h2>
        <?php foreach ($scuola['contatti_arr'] as $c): ?>
            <h4><?= htmlspecialchars($c) ?></h4>
        <?php endforeach; ?>
    </div>

    <script>
        function showTab(name, btn) {
            document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById('tab-' + name).classList.add('active');
            if (btn) btn.classList.add('active');
        }

        function openResetPass(id, username) {
            document.getElementById('modalProfId').value = id;
            document.getElementById('modalProfName').textContent = 'Professore: ' + username;
            document.getElementById('modalResetPass').classList.add('open');
        }
        function closeModal() {
            document.getElementById('modalResetPass').classList.remove('open');
        }
        document.getElementById('modalResetPass').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });

        // ── CSV IMPORT ──────────────────────────────────────────
        let importRighe = [];

        function switchImportTab(name, btn) {
            document.querySelectorAll('.import-tab-panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.import-tab').forEach(b => b.classList.remove('active'));
            document.getElementById('ipanel-' + name).classList.add('active');
            btn.classList.add('active');
            resetImport();
        }

        // CSV file input
        document.getElementById('csvImportFile').addEventListener('change', function() {
            if (!this.files[0]) return;
            document.getElementById('csvImportName').textContent = '📄 ' + this.files[0].name;
            const reader = new FileReader();
            reader.onload = e => { importRighe = parseCSVImport(e.target.result); showImportPreview(); };
            reader.readAsText(this.files[0]);
        });

        // Drag & drop CSV
        const csvDrop = document.getElementById('csvDropAdmin');
        csvDrop.addEventListener('dragover',  e => { e.preventDefault(); csvDrop.classList.add('drag-over'); });
        csvDrop.addEventListener('dragleave', () => csvDrop.classList.remove('drag-over'));
        csvDrop.addEventListener('drop', e => {
            e.preventDefault(); csvDrop.classList.remove('drag-over');
            const file = e.dataTransfer.files[0]; if (!file) return;
            document.getElementById('csvImportName').textContent = '📄 ' + file.name;
            const reader = new FileReader();
            reader.onload = ev => { importRighe = parseCSVImport(ev.target.result); showImportPreview(); };
            reader.readAsText(file);
        });

        // Bulk textarea: mostra bottone anteprima quando c'è testo
        document.getElementById('bulkImportInput').addEventListener('input', function() {
            document.getElementById('importParseBtn').style.display = this.value.trim() ? 'block' : 'none';
            document.getElementById('importPreview').style.display = 'none';
        });

        function parseImport() {
            const bulk = document.getElementById('bulkImportInput').value.trim();
            importRighe = parseCSVImport(bulk);
            showImportPreview();
        }

        function parseCSVImport(text) {
            const lines = text.split(/\r?\n/).filter(l => l.trim());
            return lines.map((line, idx) => {
                const parts = line.split(';').map(p => p.trim());
                if (parts.length < 3) return null;
                const n = parseInt(parts[2]);
                if (isNaN(n) || n <= 0) return null;
                return { classe: parts[0].toUpperCase(), sede: parts[1].toUpperCase(), n_studenti: n };
            }).filter(Boolean);
        }

        function showImportPreview() {
            if (!importRighe.length) { alert('Nessuna riga valida trovata. Controlla il formato.'); return; }
            const tbody = document.getElementById('importPreviewBody');
            tbody.innerHTML = '';
            importRighe.forEach(r => {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td><strong>${r.classe}</strong></td><td><span class="badge-sede-sm">${r.sede}</span></td><td>${r.n_studenti}</td>`;
                tbody.appendChild(tr);
            });
            document.getElementById('importCount').textContent = importRighe.length;
            document.getElementById('importRighe').value = JSON.stringify(importRighe);
            document.getElementById('importPreview').style.display = 'block';
            document.getElementById('importParseBtn').style.display = 'none';
        }

        function resetImport() {
            importRighe = [];
            document.getElementById('csvImportFile').value = '';
            document.getElementById('csvImportName').textContent = '';
            document.getElementById('bulkImportInput').value = '';
            document.getElementById('importPreview').style.display = 'none';
            document.getElementById('importParseBtn').style.display = 'none';
        }

        document.querySelectorAll('input[name="classe"]').forEach(el => {
            el.addEventListener('input', function() { this.value = this.value.toUpperCase(); });
        });
    </script>

</body>
</html>
