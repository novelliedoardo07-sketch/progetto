-- ============================================================
--  MIGRAZIONE MULTI-SCUOLA
--  Da eseguire UNA VOLTA sul database my_valutazionedocentimajo
--  Compatibile con la struttura esistente (scuola + classi già ok)
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- 1. PROF: aggiunge colonna scuola
-- ------------------------------------------------------------
ALTER TABLE `prof`
  ADD COLUMN `scuola` INT NOT NULL DEFAULT 1
    COMMENT 'FK → scuola.id'
    AFTER `password`;

ALTER TABLE `prof`
  ADD CONSTRAINT `fk_prof_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- Tutti i prof esistenti vengono assegnati alla scuola 1
UPDATE `prof` SET `scuola` = 1;

-- ------------------------------------------------------------
-- 2. STUDENTI: aggiunge colonna scuola
-- ------------------------------------------------------------
ALTER TABLE `studenti`
  ADD COLUMN `scuola` INT NOT NULL DEFAULT 1
    COMMENT 'FK → scuola.id'
    AFTER `classe`;

ALTER TABLE `studenti`
  ADD CONSTRAINT `fk_studenti_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

-- Deriviamo scuola dagli studenti esistenti tramite classi
UPDATE `studenti` s
  JOIN `classi` c ON c.classe = s.classe
  SET s.scuola = c.scuola;

-- ------------------------------------------------------------
-- 3. INSEGNA: aggiunge colonna scuola (denormalizzazione utile
--    per filtrare rapidamente i prof per scuola)
-- ------------------------------------------------------------
ALTER TABLE `insegna`
  ADD COLUMN `scuola` INT NOT NULL DEFAULT 1
    COMMENT 'FK → scuola.id'
    AFTER `classe`;

ALTER TABLE `insegna`
  ADD CONSTRAINT `fk_insegna_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

UPDATE `insegna` i
  JOIN `classi` c ON c.classe = i.classe
  SET i.scuola = c.scuola;

-- ------------------------------------------------------------
-- 4. FEEDBACK: aggiunge colonna scuola
-- ------------------------------------------------------------
ALTER TABLE `feedback`
  ADD COLUMN `scuola` INT NOT NULL DEFAULT 1
    COMMENT 'FK → scuola.id'
    AFTER `classe`;

ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_feedback_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE;

UPDATE `feedback` f
  JOIN `classi` c ON c.classe = f.classe
  SET f.scuola = c.scuola;

-- ------------------------------------------------------------
-- 5. SCUOLA: aggiunge campi utili per i header delle pagine
-- ------------------------------------------------------------
ALTER TABLE `scuola`
  ADD COLUMN `citta`      VARCHAR(100) NOT NULL DEFAULT 'Seriate' AFTER `nome`,
  ADD COLUMN `logo`       VARCHAR(255) NOT NULL DEFAULT 'logo.png' AFTER `citta`,
  ADD COLUMN `contatti`   TEXT                  DEFAULT NULL       AFTER `logo`;

-- Popola i dati della scuola esistente
UPDATE `scuola`
  SET citta    = 'Seriate',
      logo     = 'logo.png',
      contatti = 'contiero.leonardo07@majorana.org,nacuta.nicolas07@majorana.org,novelli.edoardo07@majorana.org,wassef.mena05@majorana.org'
  WHERE id = 1;

-- ------------------------------------------------------------
-- 6. USERNAME unici globali (non più solo per scuola)
--    Aggiunge indice UNIQUE su prof.username (già unico di fatto)
-- ------------------------------------------------------------
-- Verifica prima se esiste già un UNIQUE su username
-- ALTER TABLE `prof` ADD UNIQUE KEY `uq_prof_username` (`username`);
-- (commentato: eseguire solo se non esiste già)

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
--  VERIFICA FINALE
-- ============================================================
SELECT 'scuola'    AS tabella, COUNT(*) AS righe FROM scuola
UNION ALL
SELECT 'prof',      COUNT(*) FROM prof
UNION ALL
SELECT 'studenti',  COUNT(*) FROM studenti
UNION ALL
SELECT 'classi',    COUNT(*) FROM classi
UNION ALL
SELECT 'insegna',   COUNT(*) FROM insegna
UNION ALL
SELECT 'feedback',  COUNT(*) FROM feedback;
