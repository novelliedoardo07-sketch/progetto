<?php
// db.php  –  include questo file in ogni pagina PHP
// Fornisce: $pdo, $scuola (array con id, nome, citta, logo, contatti[])

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';   // <-- modifica
$dbpass = '';       // <-- modifica

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser,
        $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die('Errore di connessione al database.');
}

// -------------------------------------------------------
// Carica i dati della scuola corrente dalla sessione
// (dopo il login idScuola viene salvato in $_SESSION)
// -------------------------------------------------------
$idScuola = $_SESSION['scuola'] ?? 1;

$stmtScuola = $pdo->prepare(
    "SELECT id, nome, citta, logo, contatti FROM scuola WHERE id = ? LIMIT 1"
);
$stmtScuola->execute([$idScuola]);
$scuola = $stmtScuola->fetch(PDO::FETCH_ASSOC);

if (!$scuola) {
    die('Scuola non trovata.');
}

// Converte contatti da stringa CSV ad array
$scuola['contatti_arr'] = $scuola['contatti']
    ? array_map('trim', explode(',', $scuola['contatti']))
    : [];
