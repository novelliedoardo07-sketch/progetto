-- ============================================================
--  MIGRATION: CHIAVE DI REGISTRAZIONE PER I PROFESSORI
--  Da eseguire UNA VOLTA sul database my_valutazionedocentimajo
--  (richiede che migration_multiscuola.sql sia già stata eseguita)
-- ============================================================

ALTER TABLE `scuola`
  ADD COLUMN `codice_registrazione` VARCHAR(50) NOT NULL DEFAULT ''
    COMMENT 'Chiave segreta richiesta ai prof per registrarsi'
    AFTER `contatti`;

-- Imposta il codice per la scuola esistente (cambia il valore come vuoi)
UPDATE `scuola`
  SET `codice_registrazione` = 'MAJO-2024'
  WHERE `id` = 1;

-- ============================================================
--  VERIFICA
-- ============================================================
SELECT id, nome, codice_registrazione FROM scuola;
