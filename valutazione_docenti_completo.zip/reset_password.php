<?php
// reset_password.php
// Step 1 (GET senza token): form per inserire la mail
// Step 2 (POST senza token): invia la mail con il link
// Step 3 (GET con token):    form per inserire la nuova password
// Step 4 (POST con token):   aggiorna la password

session_start();

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('Errore di connessione al database.');
}

$token   = trim($_GET['token'] ?? '');
$msg     = '';
$error   = '';
$success = false;

// ── STEP 2: ricevi mail e manda il link ───────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$token) {
    $mail     = trim($_POST['mail']     ?? '');
    $idScuola = (int)($_POST['scuola']  ?? 0);

    if (!$mail || !$idScuola) {
        $error = 'Inserisci la tua email e seleziona la scuola.';
    } else {
        // Cerca il prof con quella mail in quella scuola
        $stmt = $pdo->prepare(
            "SELECT id FROM prof WHERE mail = ? AND scuola = ? LIMIT 1"
        );
        $stmt->execute([$mail, $idScuola]);
        $prof = $stmt->fetch(PDO::FETCH_ASSOC);

        // Risposta generica per non rivelare se la mail esiste
        $msg = "Se l'email è associata a un account, riceverai un link per il reset entro pochi minuti.";

        if ($prof) {
            // Invalida token precedenti per questo prof
            $pdo->prepare(
                "UPDATE password_reset_tokens SET usato = 1 WHERE id_prof = ? AND scuola = ?"
            )->execute([$prof['id'], $idScuola]);

            // Crea nuovo token
            $newToken = bin2hex(random_bytes(32));
            $scadeIl  = date('Y-m-d H:i:s', time() + 3600); // 1 ora

            $pdo->prepare(
                "INSERT INTO password_reset_tokens (id_prof, scuola, token, scade_il)
                 VALUES (?, ?, ?, ?)"
            )->execute([$prof['id'], $idScuola, $newToken, $scadeIl]);

            // Manda la mail
            $baseUrl = 'https://valutazionedocentimajo.altervista.org';
            $link    = "{$baseUrl}/reset_password.php?token={$newToken}";

            $oggetto = "Reset password — Valutazione Docenti";
            $corpo   = "Hai richiesto il reset della password per il tuo account professore.\n\n"
                     . "Clicca il link seguente per impostare una nuova password:\n"
                     . $link . "\n\n"
                     . "Il link è valido per 1 ora.\n\n"
                     . "Se non hai richiesto il reset, ignora questa email.\n";

            $headers  = "From: noreply@valutazionedocentimajo.altervista.org\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            mail($mail, $oggetto, $corpo, $headers);
        }
    }
}

// ── STEP 4: aggiorna la password ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $token) {
    $nuovaPass  = trim($_POST['password']  ?? '');
    $conferma   = trim($_POST['conferma']  ?? '');

    if (!$nuovaPass || !$conferma) {
        $error = 'Compila tutti i campi.';
    } elseif (strlen($nuovaPass) > 10) {
        $error = 'La password non può superare i 10 caratteri.';
    } elseif ($nuovaPass !== $conferma) {
        $error = 'Le password non coincidono.';
    } else {
        // Verifica token
        $stmt = $pdo->prepare(
            "SELECT id, id_prof, scuola FROM password_reset_tokens
             WHERE token = ? AND usato = 0 AND scade_il > NOW()
             LIMIT 1"
        );
        $stmt->execute([$token]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            $error = 'Il link non è valido o è scaduto. Richiedi un nuovo reset.';
        } else {
            // Aggiorna password
            $hash = password_hash($nuovaPass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE prof SET password = ? WHERE id = ?")->execute([$hash, $row['id_prof']]);

            // Invalida il token
            $pdo->prepare("UPDATE password_reset_tokens SET usato = 1 WHERE id = ?")->execute([$row['id']]);

            $success = true;
            $msg     = 'Password aggiornata con successo! Puoi ora accedere con la nuova password.';
        }
    }
}

// ── STEP 3: verifica token per mostrare il form ───────────────
$tokenValido = false;
if ($token && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare(
        "SELECT id FROM password_reset_tokens
         WHERE token = ? AND usato = 0 AND scade_il > NOW()
         LIMIT 1"
    );
    $stmt->execute([$token]);
    $tokenValido = (bool)$stmt->fetch();
    if (!$tokenValido) {
        $error = 'Il link non è valido o è scaduto. Richiedi un nuovo reset.';
    }
}

// Carica scuole per il select
$scuole = $pdo->query("SELECT id, nome, citta FROM scuola ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password — Valutazione Docenti</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        #reset-box {
            max-width: 440px;
            margin: 0 auto 28px;
            background: white;
            padding: 32px 30px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--grigio-brd);
            box-shadow: var(--shadow-md);
        }
        #reset-box h2 {
            font-family: 'Barlow Condensed', sans-serif;
            font-size: 24px; font-weight: 800;
            color: var(--blu); margin-bottom: 6px;
        }
        #reset-box p.subtitle {
            font-size: 14px; color: #888;
            margin-bottom: 22px; line-height: 1.5;
        }
        .msg-ok  { background:#dcfce7; color:#166534; border:1px solid #86efac; border-radius:var(--radius-sm); padding:12px 16px; margin-bottom:16px; font-weight:600; font-size:14px; }
        .msg-err { background:#fee2e2; color:#991b1b; border:1px solid #fca5a5; border-radius:var(--radius-sm); padding:12px 16px; margin-bottom:16px; font-weight:600; font-size:14px; }
    </style>
</head>
<body>

    <header class="page-hero">
        <h1>Valutazione Docenti</h1>
        <h2>Reset Password</h2>
    </header>

    <div id="reset-box">

        <?php if ($msg && $success): ?>
            <div class="msg-ok">✅ <?= htmlspecialchars($msg) ?></div>
            <a href="login.php" style="display:block; text-align:center; margin-top:10px;">
                <button type="button">Vai al Login →</button>
            </a>

        <?php elseif ($msg && !$token): ?>
            <div class="msg-ok">📧 <?= htmlspecialchars($msg) ?></div>
            <p style="font-size:13px; color:#888; text-align:center; margin-top:10px;">
                <a href="login.php">← Torna al login</a>
            </p>

        <?php elseif ($error && !$tokenValido): ?>
            <div class="msg-err">❌ <?= htmlspecialchars($error) ?></div>
            <p style="font-size:13px; color:#888; text-align:center; margin-top:10px;">
                <a href="reset_password.php">Richiedi un nuovo link</a> &nbsp;·&nbsp;
                <a href="login.php">Torna al login</a>
            </p>

        <?php elseif ($token && $tokenValido): ?>
            <!-- STEP 3-4: form nuova password -->
            <h2>🔑 Nuova Password</h2>
            <p class="subtitle">Scegli una nuova password per il tuo account.</p>

            <?php if ($error): ?>
                <div class="msg-err">❌ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="reset_password.php?token=<?= htmlspecialchars($token) ?>">
                <label for="password">Nuova password</label>
                <input type="password" name="password" id="password"
                       placeholder="Max 10 caratteri" maxlength="10" required autocomplete="new-password">

                <label for="conferma">Conferma password</label>
                <input type="password" name="conferma" id="conferma"
                       placeholder="Ripeti la password" maxlength="10" required autocomplete="new-password">

                <button type="submit">Aggiorna Password</button>
            </form>

        <?php else: ?>
            <!-- STEP 1-2: form richiesta reset -->
            <h2>🔐 Password dimenticata?</h2>
            <p class="subtitle">Inserisci la tua email e seleziona la scuola.<br>Ti invieremo un link per reimpostare la password.</p>

            <?php if ($error): ?>
                <div class="msg-err">❌ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="reset_password.php">
                <label for="scuola">Istituto scolastico</label>
                <select name="scuola" id="scuola" required>
                    <option value="">— seleziona la scuola —</option>
                    <?php foreach ($scuole as $s): ?>
                        <option value="<?= $s['id'] ?>"
                            <?= ((int)($_POST['scuola'] ?? 0) === (int)$s['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s['nome']) ?> – <?= htmlspecialchars($s['citta']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="mail">Email</label>
                <input type="email" name="mail" id="mail"
                       placeholder="La tua email registrata"
                       value="<?= htmlspecialchars($_POST['mail'] ?? '') ?>"
                       required autocomplete="email">

                <button type="submit">Invia link di reset</button>
            </form>

            <p style="font-size:13px; color:#888; text-align:center; margin-top:16px;">
                <a href="login.php">← Torna al login</a>
            </p>
        <?php endif; ?>

    </div>

    <div id="contatti">
        <h2>Contatti</h2>
        <h4>Per assistenza contatta l'amministratore del sistema.</h4>
    </div>

</body>
</html>
