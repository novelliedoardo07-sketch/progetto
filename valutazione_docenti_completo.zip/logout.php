<?php
session_start();
session_unset();
session_destroy();

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout – Valutazione Docenti</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        #logout-box { max-width:440px; text-align:center; }
        #logout-box h2 { font-family:'Barlow Condensed',sans-serif; font-size:28px; font-weight:800; color:var(--blu); text-align:center; margin-bottom:14px; }
        #logout-box p { font-size:15px; color:var(--testo-soft); margin-bottom:10px; line-height:1.6; }
        #logout-box button { display:inline-block; width:auto; padding:12px 36px; margin-top:18px; }
    </style>
</head>
<body>

    <header class="page-hero">
        <h1>Valutazione Docenti</h1>
        <h2>Sessione terminata</h2>
    </header>

    <div id="logout-box">
        <h2>Sei uscito</h2>
        <p>La tua sessione è stata terminata correttamente.</p>
        <p>Verrai reindirizzato al login tra <span id="countdown">3</span> secondi…</p>
        <button onclick="window.location.href='login.php'">Torna al login</button>
    </div>

    <div id="contatti">
        <h2>Contatti</h2>
        <h4>Per assistenza contatta l'amministratore del sistema.</h4>
    </div>

    <script>
        let sec = 3;
        const el = document.getElementById('countdown');
        const timer = setInterval(() => {
            sec--;
            el.textContent = sec;
            if (sec <= 0) { clearInterval(timer); window.location.href = 'login.php'; }
        }, 1000);
    </script>

</body>
</html>
