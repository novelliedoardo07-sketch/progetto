-- ============================================================
--  MIGRATION: TABELLA SUPER_ADMIN
--  Il super admin non è legato a una scuola specifica
--  e può gestire tutto il sistema.
-- ============================================================

CREATE TABLE IF NOT EXISTS `super_admin` (
  `id`       INT          NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL COLLATE utf8mb4_general_ci,
  `password` VARCHAR(255) NOT NULL COLLATE utf8mb4_general_ci COMMENT 'bcrypt hash',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_superadmin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================
--  Crea il primo super admin
--  La password viene hashata con bcrypt dallo script reset_superadmin.php
--  NON inserire la password in chiaro qui
-- ============================================================

-- VERIFICA
SELECT 'super_admin' AS tabella, COUNT(*) AS righe FROM super_admin;
