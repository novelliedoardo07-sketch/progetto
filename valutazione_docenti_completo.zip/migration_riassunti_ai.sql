-- ============================================================
--  MIGRATION: TABELLA RIASSUNTI AI
--  Salva il riassunto generato per ogni prof/classe
-- ============================================================

CREATE TABLE IF NOT EXISTS `riassunti_ai` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `idProf`     INT          NOT NULL COMMENT 'FK → prof.id',
  `classe`     VARCHAR(6)   NOT NULL COLLATE utf8mb4_general_ci,
  `scuola`     INT          NOT NULL COMMENT 'FK → scuola.id',
  `riassunto`  TEXT         NOT NULL COLLATE utf8mb4_general_ci,
  `n_feedback` INT          NOT NULL DEFAULT 0,
  `creato_il`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_riassunto` (`idProf`, `classe`, `scuola`),
  CONSTRAINT `fk_riassunto_prof`
    FOREIGN KEY (`idProf`) REFERENCES `prof` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_riassunto_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- VERIFICA
SELECT 'riassunti_ai' AS tabella, COUNT(*) AS righe FROM riassunti_ai;
