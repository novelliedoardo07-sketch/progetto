<?php
// ai_get_confronto.php  –  legge i due riassunti (anno corrente e precedente)
// e costruisce il prompt per il confronto AI

header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['ruolo'] !== 'prof') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accesso negato.']);
    exit;
}

$idProf   = (int)$_SESSION['user_id'];
$idScuola = (int)$_SESSION['scuola'];

$data        = json_decode(file_get_contents('php://input'), true);
$classe      = trim($data['classe']         ?? '');
$annoPre     = trim($data['anno_precedente'] ?? '');

if (!$classe || !$annoPre) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Dati mancanti.']);
    exit;
}

require_once 'db.php';
require_once 'crypto.php';

$annoCorrente = $scuola['anno_scolastico'] ?? '2024-2025';

// Verifica che il prof insegni in questa classe
$chk = $pdo->prepare("SELECT 1 FROM insegna WHERE id = ? AND classe = ? AND scuola = ?");
$chk->execute([$idProf, $classe, $idScuola]);
if (!$chk->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Classe non autorizzata.']);
    exit;
}

// Leggi il riassunto dell'anno corrente
$stmtC = $pdo->prepare(
    "SELECT riassunto FROM riassunti_ai
     WHERE idProf = ? AND classe = ? AND scuola = ? AND anno_scolastico = ?
     LIMIT 1"
);
$stmtC->execute([$idProf, $classe, $idScuola, $annoCorrente]);
$rowC = $stmtC->fetch(PDO::FETCH_ASSOC);

if (!$rowC) {
    echo json_encode(['success' => false, 'error' => "Riassunto anno {$annoCorrente} non trovato."]);
    exit;
}

// Leggi il riassunto dell'anno precedente
$stmtP = $pdo->prepare(
    "SELECT riassunto FROM riassunti_ai
     WHERE idProf = ? AND classe = ? AND scuola = ? AND anno_scolastico = ?
     LIMIT 1"
);
$stmtP->execute([$idProf, $classe, $idScuola, $annoPre]);
$rowP = $stmtP->fetch(PDO::FETCH_ASSOC);

if (!$rowP) {
    echo json_encode(['success' => false, 'error' => "Riassunto anno {$annoPre} non trovato."]);
    exit;
}

$riassuntoCorrente   = decrypt($rowC['riassunto']);
$riassuntoPrecedente = decrypt($rowP['riassunto']);

// Costruisce il prompt di confronto
$prompt = "Sei un assistente che aiuta i professori a monitorare la propria crescita professionale nel tempo.\n\n"
    . "Ti vengono forniti due riassunti dei feedback degli studenti della classe {$classe}, "
    . "relativi a due anni scolastici diversi.\n\n"
    . "## Riassunto anno {$annoPre}:\n"
    . $riassuntoPrecedente . "\n\n"
    . "## Riassunto anno {$annoCorrente}:\n"
    . $riassuntoCorrente . "\n\n"
    . "Il tuo compito:\n"
    . "1. Confronta i due riassunti e identifica cosa è migliorato, cosa è peggiorato e cosa è rimasto invariato.\n"
    . "2. Organizza il confronto per categoria (Lato Professionale, Lato Umano, Altro) dove applicabile.\n"
    . "3. Scrivi in modo costruttivo e professionale, come se stessi scrivendo una relazione per il professore.\n"
    . "4. Concludi con una valutazione generale del percorso di crescita.\n"
    . "5. Usa titoli con ## per ogni sezione.\n"
    . "6. Rispondi in italiano.\n";

echo json_encode([
    'success'       => true,
    'prompt'        => $prompt,
    'anno_corrente' => $annoCorrente,
    'anno_pre'      => $annoPre,
]);
