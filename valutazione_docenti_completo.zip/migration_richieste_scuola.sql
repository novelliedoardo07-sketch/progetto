-- ============================================================
--  MIGRATION: TABELLA RICHIESTE_SCUOLA
--  Salva le richieste di registrazione in attesa di approvazione
-- ============================================================

CREATE TABLE IF NOT EXISTS `richieste_scuola` (
  `id`             INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `nome`           VARCHAR(255)  NOT NULL,
  `citta`          VARCHAR(100)  NOT NULL,
  `logo`           VARCHAR(255)  NOT NULL DEFAULT 'logo.png',
  `contatti`       TEXT          DEFAULT NULL,
  `admin_username` VARCHAR(100)  NOT NULL,
  `admin_password` VARCHAR(255)  NOT NULL COMMENT 'bcrypt hash',
  `codice_reg`     VARCHAR(255)  NOT NULL COMMENT 'bcrypt hash',
  `classi_json`    LONGTEXT      NOT NULL COMMENT 'JSON array delle classi',
  `token`          VARCHAR(64)   NOT NULL COMMENT 'token univoco per approvazione via link',
  `stato`          ENUM('in_attesa','approvata','rifiutata') NOT NULL DEFAULT 'in_attesa',
  `creato_il`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gestita_il`     DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- VERIFICA
SELECT 'richieste_scuola' AS tabella, COUNT(*) AS righe FROM richieste_scuola;
