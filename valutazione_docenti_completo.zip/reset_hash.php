<?php
// reset_hash.php
// Script ONE-SHOT: hasha le password dei prof esistenti (in chiaro)
// e il codice_registrazione della scuola.
// ESEGUILO UNA VOLTA VIA BROWSER O CLI, POI CANCELLALO DAL SERVER.

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('Connessione fallita: ' . $e->getMessage());
}

echo "<pre>\n";

// ── 1. Hasha password prof in chiaro ─────────────────────────
$profs   = $pdo->query("SELECT id, username, password FROM prof")->fetchAll(PDO::FETCH_ASSOC);
$updProf = $pdo->prepare("UPDATE prof SET password = ? WHERE id = ?");

foreach ($profs as $p) {
    if (str_starts_with($p['password'], '$2y$')) {
        echo "Prof [{$p['username']}] — già hashata, skip.\n";
        continue;
    }
    $hash = password_hash($p['password'], PASSWORD_BCRYPT);
    $updProf->execute([$hash, $p['id']]);
    echo "Prof [{$p['username']}] — password hashata.\n";
}

// ── 2. Hasha codice_registrazione scuole in chiaro ───────────
$scuole    = $pdo->query("SELECT id, nome, codice_registrazione FROM scuola")->fetchAll(PDO::FETCH_ASSOC);
$updScuola = $pdo->prepare("UPDATE scuola SET codice_registrazione = ? WHERE id = ?");

foreach ($scuole as $s) {
    if (str_starts_with($s['codice_registrazione'], '$2y$')) {
        echo "Scuola [{$s['nome']}] — codice già hashato, skip.\n";
        continue;
    }
    if (empty($s['codice_registrazione'])) {
        echo "Scuola [{$s['nome']}] — codice vuoto, skip.\n";
        continue;
    }
    $hash = password_hash($s['codice_registrazione'], PASSWORD_BCRYPT);
    $updScuola->execute([$hash, $s['id']]);
    echo "Scuola [{$s['nome']}] — codice_registrazione hashato.\n";
}

// ── 3. Aggiorna password amministratore ──────────────────────
// INSERT ... ON DUPLICATE KEY UPDATE: funziona sia se l'admin esiste già
// sia se non esiste ancora — può essere eseguito più volte senza errori.
$passAdmin = 'admin';   // <-- cambia con la password che vuoi
$hashAdmin = password_hash($passAdmin, PASSWORD_BCRYPT);

$pdo->prepare(
    "INSERT INTO amministratori (username, password, scuola)
     VALUES (?, ?, 1)
     ON DUPLICATE KEY UPDATE password = VALUES(password)"
)->execute(['admin', $hashAdmin]);

echo "Amministratore [admin] — password impostata.\n";

echo "\nFatto! Cancella questo file dal server.\n</pre>";
