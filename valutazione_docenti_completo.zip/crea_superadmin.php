<?php
// crea_superadmin.php  –  script ONE-SHOT
// Crea il primo super admin con password hashata.
// ESEGUILO UNA VOLTA VIA BROWSER, POI CANCELLALO DAL SERVER.

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

$username = 'superadmin';   // <-- cambia se vuoi
$password = 'SCEGLI_PASSWORD_SICURA'; // <-- cambia con la tua password

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('Connessione fallita: ' . $e->getMessage());
}

$hash = password_hash($password, PASSWORD_BCRYPT);

try {
    $pdo->prepare(
        "INSERT INTO super_admin (username, password) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE password = VALUES(password)"
    )->execute([$username, $hash]);
    echo "<pre>Super admin [{$username}] creato/aggiornato con successo.\nCancella questo file dal server.</pre>";
} catch (PDOException $e) {
    die('Errore: ' . $e->getMessage());
}
