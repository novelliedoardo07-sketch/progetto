<?php
// ai_get_feedback.php  –  legge i feedback dal DB e costruisce il prompt
// Chiamato dal browser prima di contattare il Worker Cloudflare

header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['ruolo'] !== 'prof') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accesso negato.']);
    exit;
}

$idProf   = (int)$_SESSION['user_id'];
$idScuola = (int)$_SESSION['scuola'];

$data          = json_decode(file_get_contents('php://input'), true);
$classe        = trim($data['classe']        ?? '');
$annoScolastico = trim($data['anno_scolastico'] ?? '');

if (!$classe || !$annoScolastico) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Classe non specificata.']);
    exit;
}

require_once 'db.php';
require_once 'crypto.php';

// Verifica che il prof insegni in questa classe
$chk = $pdo->prepare("SELECT 1 FROM insegna WHERE id = ? AND classe = ? AND scuola = ?");
$chk->execute([$idProf, $classe, $idScuola]);
if (!$chk->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Classe non autorizzata.']);
    exit;
}

// Controlla se esiste già un riassunto — se sì, non serve chiamare l'AI
$chkR = $pdo->prepare("SELECT 1 FROM riassunti_ai WHERE idProf = ? AND classe = ? AND scuola = ? AND anno_scolastico = ? LIMIT 1");
$chkR->execute([$idProf, $classe, $idScuola, $annoScolastico]);
if ($chkR->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Riassunto già generato per questa classe.']);
    exit;
}

// Legge i feedback
$stmt = $pdo->prepare(
    "SELECT categoria, positivo, negativo
     FROM feedback
     WHERE idProf = ? AND classe = ? AND scuola = ? AND anno_scolastico = ?
     ORDER BY categoria, creato_il DESC"
);
$stmt->execute([$idProf, $classe, $idScuola, $annoScolastico]);
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($feedbacks)) {
    echo json_encode(['success' => false, 'error' => 'Nessun feedback disponibile.']);
    exit;
}

// Costruisce il testo dei feedback
$labelCategorie = [
    'professionale' => 'Lato Professionale',
    'umano'         => 'Lato Umano',
    'altro'         => 'Altro',
];

$grouped = [];
foreach ($feedbacks as $fb) {
    $grouped[$fb['categoria']][] = $fb;
}

$testoFeedback = '';
foreach ($grouped as $cat => $items) {
    $label = $labelCategorie[$cat] ?? $cat;
    $testoFeedback .= "\n### {$label}\n";
    foreach ($items as $fb) {
        $testoFeedback .= "- Positivo: " . decrypt($fb['positivo']) . "\n";
        $testoFeedback .= "  Negativo: " . decrypt($fb['negativo']) . "\n";
    }
}

$nFeedback = count($feedbacks);

$prompt = "Sei un assistente che aiuta i professori a capire cosa pensano i propri studenti.\n"
    . "Ti vengono forniti i feedback anonimi degli studenti della classe {$classe}, divisi per categoria.\n\n"
    . "Il tuo compito:\n"
    . "1. Ignora completamente qualsiasi feedback offensivo, volgare, insultante o non pertinente.\n"
    . "2. Per ogni categoria (Lato Professionale, Lato Umano, Altro), scrivi un riassunto sintetico "
    . "e costruttivo di massimo 4-5 frasi che catturi i temi ricorrenti, sia positivi che negativi.\n"
    . "3. Usa un tono professionale e oggettivo.\n"
    . "4. Non elencare i singoli feedback, sintetizzali in un discorso fluente.\n"
    . "5. Se per una categoria non ci sono feedback validi, scrivi \"Nessun feedback significativo per questa categoria.\"\n"
    . "6. Usa titoli con ## per ogni categoria.\n"
    . "7. Rispondi in italiano.\n\n"
    . "Feedback degli studenti:\n"
    . $testoFeedback;

echo json_encode([
    'success'        => true,
    'prompt'         => $prompt,
    'n_feedback'     => $nFeedback,
    'anno_scolastico' => $annoScolastico,
]);
