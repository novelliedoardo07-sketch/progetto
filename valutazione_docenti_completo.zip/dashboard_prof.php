<?php
require_once 'auth_check.php';

if ($_SESSION['ruolo'] !== 'prof') {
    header('Location: valutazione.php');
    exit;
}

$idProf   = $_SESSION['user_id'];
$nomeProf = $_SESSION['nome'];
$idScuola = (int)$_SESSION['scuola'];

require_once 'db.php';
require_once 'crypto.php';

// ── Classi del prof ───────────────────────────────────────────
$stmtClassi = $pdo->prepare(
    "SELECT i.classe, c.sede, c.n_studenti
     FROM insegna i
     JOIN classi c ON c.classe = i.classe AND c.scuola = i.scuola
     WHERE i.id = ? AND i.scuola = ?
     ORDER BY i.classe"
);
$stmtClassi->execute([$idProf, $idScuola]);
$classi = $stmtClassi->fetchAll(PDO::FETCH_ASSOC);

// ── Conteggio votanti e feedback totali per classe ────────────
$stmtCount = $pdo->prepare(
    "SELECT classe, COUNT(DISTINCT idUser) AS n_votanti, COUNT(*) AS n_feedback
     FROM feedback
     WHERE idProf = ? AND scuola = ?
     GROUP BY classe"
);
$stmtCount->execute([$idProf, $idScuola]);
$statsPerClasse = [];
$totFeedback    = 0;
foreach ($stmtCount->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $statsPerClasse[$row['classe']] = $row;
    $totFeedback += $row['n_feedback'];
}

// ── Anno scolastico corrente ──────────────────────────────────
$annoCorrente = $scuola['anno_scolastico'] ?? '2024-2025';

// ── Riassunti AI salvati (tutti gli anni) ─────────────────────
$stmtRiassunti = $pdo->prepare(
    "SELECT classe, riassunto, n_feedback, creato_il, anno_scolastico
     FROM riassunti_ai
     WHERE idProf = ? AND scuola = ?
     ORDER BY anno_scolastico DESC"
);
$stmtRiassunti->execute([$idProf, $idScuola]);
// $riassuntiSalvati[classe][anno] = dati
$riassuntiSalvati = [];
$anniPerClasse    = []; // lista anni disponibili per classe
$tuttiGliAnni     = []; // tutti gli anni con almeno un riassunto
foreach ($stmtRiassunti->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $r['riassunto'] = decrypt($r['riassunto']);
    $riassuntiSalvati[$r['classe']][$r['anno_scolastico']] = $r;
    $anniPerClasse[$r['classe']][] = $r['anno_scolastico'];
    $tuttiGliAnni[$r['anno_scolastico']] = true;
}
$tuttiGliAnni = array_keys($tuttiGliAnni);
rsort($tuttiGliAnni); // dal più recente

// Anno visualizzato (dal GET o quello corrente)
$annoVista = trim($_GET['anno'] ?? $annoCorrente);
if (!in_array($annoVista, $tuttiGliAnni) && !empty($tuttiGliAnni)) {
    $annoVista = $tuttiGliAnni[0]; // fallback al più recente
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard – <?= htmlspecialchars($nomeProf) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        #header-prof { margin-top: 0; }

        /* ── AI SUMMARY CARD ── */
        .ai-card {
            background: white;
            border: 1px solid var(--grigio-brd);
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            box-shadow: var(--shadow-md);
            overflow: hidden;
        }
        .ai-card-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 16px 22px; cursor: pointer;
            background: white; gap: 12px;
            transition: background .15s;
        }
        .ai-card-header:hover { background: var(--grigio-bg); }
        .ai-card-header h3 {
            font-family: 'Barlow Condensed', sans-serif;
            font-size: 20px; font-weight: 800; color: var(--testo);
            margin: 0; display: flex; align-items: center; gap: 10px;
        }
        .ai-card-header .right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
        .ai-card-body { display: none; padding: 0 22px 22px; }
        .ai-card-body.open { display: block; }

        /* ── BOTTONE GENERA ── */
        .btn-ai {
            font-family: 'Barlow Condensed', sans-serif;
            font-size: 14px; font-weight: 700;
            padding: 7px 18px; border-radius: 100px;
            background: linear-gradient(135deg, #1a5fa8, #0d3a7a);
            color: white; border: none; cursor: pointer;
            box-shadow: 0 3px 10px rgba(26,95,168,.35);
            transition: opacity .2s, transform .15s;
            white-space: nowrap;
        }
        .btn-ai:hover { opacity: .88; transform: translateY(-1px); }
        .btn-ai:disabled { opacity: .5; cursor: not-allowed; transform: none; }

        /* ── RIASSUNTO AI ── */
        .ai-result {
            margin-top: 16px;
            border: 1px solid #c8d4ff;
            border-radius: var(--radius-md);
            background: linear-gradient(135deg, #f0f4ff 0%, #fff 100%);
            overflow: hidden;
        }
        .ai-result-header {
            display: flex; align-items: center; gap: 8px;
            padding: 10px 16px;
            background: var(--blu-light);
            border-bottom: 1px solid #c8d4ff;
            font-size: 12px; font-weight: 700; color: var(--blu);
            text-transform: uppercase; letter-spacing: .5px;
        }
        .ai-result-body {
            padding: 16px 18px;
            font-size: 15px; line-height: 1.75; color: var(--testo);
            white-space: pre-wrap;
        }
        .ai-result-body h2, .ai-result-body h3 {
            font-family: 'Barlow Condensed', sans-serif;
            font-size: 17px; font-weight: 800;
            color: var(--blu); margin: 16px 0 6px;
        }
        .ai-result-body h2:first-child, .ai-result-body h3:first-child { margin-top: 0; }

        /* ── LOADING ── */
        .ai-loading {
            display: none; align-items: center; gap: 10px;
            margin-top: 16px; padding: 14px 16px;
            background: var(--grigio-bg); border-radius: var(--radius-md);
            font-size: 14px; color: #666;
        }
        .ai-loading.show { display: flex; }
        .spinner {
            width: 20px; height: 20px; border-radius: 50%;
            border: 3px solid #ddd; border-top-color: var(--blu);
            animation: spin .8s linear infinite; flex-shrink: 0;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* ── ERRORE AI ── */
        .ai-error {
            display: none; margin-top: 16px; padding: 12px 16px;
            background: #fff0f0; border: 1px solid #fca5a5;
            border-radius: var(--radius-md);
            font-size: 14px; color: #991b1b; font-weight: 600;
        }
        .ai-error.show { display: block; }

        /* ── STATO VUOTO ── */
        .no-feedback-msg {
            padding: 20px; text-align: center;
            font-size: 14px; color: #888;
        }

        /* ── MARKDOWN RENDERING ── */
        .md-render h2 { font-family:'Barlow Condensed',sans-serif; font-size:18px; font-weight:800; color:var(--blu); margin:18px 0 6px; }
        .md-render h3 { font-family:'Barlow Condensed',sans-serif; font-size:16px; font-weight:700; color:var(--blu); margin:14px 0 5px; }
        .md-render p  { margin: 0 0 10px; }
        .md-render p:last-child { margin-bottom: 0; }
        .md-render strong { font-weight: 700; }
    </style>
</head>
<body>

    <img src="<?= htmlspecialchars($scuola['logo']) ?>" alt="logo scuola" id="logo1">
    <button id="homeBtn" onclick="window.location.href='logout.php'">Esci</button>

    <header class="page-hero">
        <h1>Dashboard Professore</h1>
        <h2><?= htmlspecialchars($scuola['nome']) ?> – <?= htmlspecialchars($scuola['citta']) ?></h2>
    </header>

    <div id="header-prof">
        <div>
            <div class="prof-nome"><?= htmlspecialchars($nomeProf) ?></div>
            <div class="prof-stats">
                Classi assegnate: <span><?= count($classi) ?></span>
                &nbsp;|&nbsp;
                Feedback ricevuti: <span><?= $totFeedback ?></span>
            </div>
        </div>
    </div>

    <?php if (empty($classi)): ?>
        <div id="stato-vuoto">
            <p>😔 Nessuna classe assegnata ancora.</p>
            <p style="margin-top:10px; font-size:13px;">Contatta l'amministratore per verificare la configurazione.</p>
        </div>

    <?php else: ?>

        <?php if (!empty($tuttiGliAnni)): ?>
        <div id="anno-wrap" style="max-width:900px; margin:0 auto 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; padding:0 20px;">
            <label for="sel-anno" style="font-weight:600; font-size:14px; color:#555; margin:0;">📅 Anno scolastico:</label>
            <select id="sel-anno" onchange="cambiaAnno(this.value)" style="width:auto; margin:0; padding:7px 14px; font-size:14px;">
                <?php foreach ($tuttiGliAnni as $an): ?>
                    <option value="<?= htmlspecialchars($an) ?>" <?= $an === $annoVista ? 'selected' : '' ?>>
                        <?= htmlspecialchars($an) ?><?= $an === $annoCorrente ? ' (corrente)' : '' ?>
                    </option>
                <?php endforeach; ?>
                <?php if (!in_array($annoCorrente, $tuttiGliAnni)): ?>
                    <option value="<?= htmlspecialchars($annoCorrente) ?>" selected>
                        <?= htmlspecialchars($annoCorrente) ?> (corrente — nessun riassunto)
                    </option>
                <?php endif; ?>
            </select>
        </div>
        <?php endif; ?>

        <?php if (count($classi) > 1): ?>
        <div id="filtro-wrap">
            <label for="filtro-classe">Filtra per classe:</label>
            <select id="filtro-classe" onchange="filtraClasse(this.value)">
                <option value="tutte">— Tutte le classi —</option>
                <?php foreach ($classi as $cl): ?>
                    <option value="ai-card-<?= htmlspecialchars($cl['classe']) ?>">
                        <?= htmlspecialchars($cl['classe']) ?> (<?= htmlspecialchars($cl['sede']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>

        <?php foreach ($classi as $cl):
            $cls       = $cl['classe'];
            $stats     = $statsPerClasse[$cls] ?? ['n_votanti' => 0, 'n_feedback' => 0];
            $nVotanti  = $stats['n_votanti'];
            $nFeedback = $stats['n_feedback'];
            $hasFeedback = $nFeedback > 0;
        ?>
        <div class="ai-card" id="ai-card-<?= htmlspecialchars($cls) ?>">

            <div class="ai-card-header" onclick="toggleCard('<?= htmlspecialchars($cls) ?>')">
                <h3>
                    📋 Classe <?= htmlspecialchars($cls) ?> – <?= htmlspecialchars($cl['sede']) ?>
                </h3>
                <div class="right">
                    <span class="badge"><?= $nVotanti ?> / <?= $cl['n_studenti'] ?> studenti hanno votato</span>
                    <?php if ($hasFeedback): ?>
                        <?php if (!isset($riassuntiSalvati[$cls][$annoVista])): ?>
                        <button class="btn-ai" id="btn-<?= htmlspecialchars($cls) ?>"
                            onclick="event.stopPropagation(); generaRiassunto('<?= htmlspecialchars($cls) ?>', '<?= htmlspecialchars($annoVista) ?>')">
                            ✨ Genera Riassunto AI
                        </button>
                        <?php else: ?>
                        <span style="font-size:12px; color:#888; font-style:italic;">
                            Generato il <?= date('d/m/Y', strtotime($riassuntiSalvati[$cls][$annoVista]['creato_il'])) ?>
                        </span>
                        <?php endif; ?>
                    <?php endif; ?>
                    <span class="arrow">▼</span>
                </div>
            </div>

            <div class="ai-card-body" id="body-<?= htmlspecialchars($cls) ?>">

                <?php if (!$hasFeedback): ?>
                    <div class="no-feedback-msg">Nessun feedback ricevuto da questa classe ancora.</div>

                <?php elseif (isset($riassuntiSalvati[$cls][$annoVista])): ?>
                    <?php $r = $riassuntiSalvati[$cls][$annoVista]; ?>
                    <div class="ai-result">
                        <div class="ai-result-header">
                            🤖 Riassunto AI <?= htmlspecialchars($annoVista) ?> · <?= $r['n_feedback'] ?> feedback · <?= date('d/m/Y H:i', strtotime($r['creato_il'])) ?>
                        </div>
                        <div class="ai-result-body md-render" id="result-<?= htmlspecialchars($cls) ?>"><?= htmlspecialchars($r['riassunto']) ?></div>
                    </div>
                    <?php
                    // Anni precedenti disponibili per confronto
                    $anniPrecedenti = array_filter($anniPerClasse[$cls] ?? [], fn($a) => $a !== $annoVista);
                    if (!empty($anniPrecedenti)): ?>
                    <div style="margin-top:14px;">
                        <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                            <select id="anno-sel-<?= htmlspecialchars($cls) ?>" style="width:auto; margin:0; padding:7px 12px; font-size:13px;">
                                <?php foreach ($anniPrecedenti as $annoPre): ?>
                                    <option value="<?= htmlspecialchars($annoPre) ?>"><?= htmlspecialchars($annoPre) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn-ai" onclick="generaConfronto('<?= htmlspecialchars($cls) ?>')">
                                📊 Confronta con anno precedente
                            </button>
                        </div>
                        <div class="ai-loading" id="loading-confronto-<?= htmlspecialchars($cls) ?>">
                            <div class="spinner"></div>
                            <span>Sto generando il confronto con l'AI…</span>
                        </div>
                        <div class="ai-error" id="error-confronto-<?= htmlspecialchars($cls) ?>"></div>
                        <div id="result-confronto-<?= htmlspecialchars($cls) ?>"></div>
                    </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="ai-loading" id="loading-<?= htmlspecialchars($cls) ?>">
                        <div class="spinner"></div>
                        <span>Sto analizzando i feedback con l'AI, attendere…</span>
                    </div>
                    <div class="ai-error" id="error-<?= htmlspecialchars($cls) ?>"></div>
                    <div id="result-<?= htmlspecialchars($cls) ?>"></div>
                    <p style="font-size:12px; color:#aaa; margin-top:14px; text-align:right;">
                        Basato su <?= $nFeedback ?> feedback · I contenuti offensivi vengono automaticamente esclusi
                    </p>
                <?php endif; ?>

            </div>
        </div>
        <?php endforeach; ?>

    <?php endif; ?>

    <div style="text-align:center; margin: 0 auto 28px;">
        <button onclick="window.location.href='https://valutazionedocentimajo.altervista.org/test.php'" style="width:auto; padding:12px 36px;">
            🔗 Vai a Test
        </button>
    </div>

    <div id="contatti">
        <h2>I nostri contatti</h2>
        <?php foreach ($scuola['contatti_arr'] as $c): ?>
            <h4><?= htmlspecialchars($c) ?></h4>
        <?php endforeach; ?>
    </div>

    <script>
        // ── TOGGLE CARD ───────────────────────────────────────────
        function toggleCard(cls) {
            const body   = document.getElementById('body-' + cls);
            const card   = document.getElementById('ai-card-' + cls);
            const arrow  = card.querySelector('.arrow');
            const isOpen = body.classList.toggle('open');
            arrow.textContent = isOpen ? '▲' : '▼';
        }

        // ── FILTRO CLASSI ─────────────────────────────────────────
        function filtraClasse(valore) {
            document.querySelectorAll('.ai-card').forEach(card => {
                card.style.display = (valore === 'tutte' || card.id === valore) ? 'block' : 'none';
            });
        }

        // ── GENERA RIASSUNTO AI ───────────────────────────────────
        const WORKER_URL = 'https://green-glitter-5b4d.novelli-edoardo07.workers.dev';
        const riassuntiCache = {};

        async function generaRiassunto(cls, anno) {
            if (riassuntiCache[cls]) {
                const body = document.getElementById('body-' + cls);
                if (!body.classList.contains('open')) {
                    body.classList.add('open');
                    document.querySelector('#ai-card-' + cls + ' .arrow').textContent = '▲';
                }
                return;
            }

            const btn      = document.getElementById('btn-' + cls);
            const loading  = document.getElementById('loading-' + cls);
            const errEl    = document.getElementById('error-' + cls);
            const resultEl = document.getElementById('result-' + cls);
            const body     = document.getElementById('body-' + cls);

            // Apri la card e mostra loading
            body.classList.add('open');
            document.querySelector('#ai-card-' + cls + ' .arrow').textContent = '▲';
            btn.disabled    = true;
            btn.textContent = '⏳ Elaborazione…';
            loading.classList.add('show');
            errEl.classList.remove('show');
            resultEl.innerHTML = '';

            try {
                // 1. Leggi i feedback tramite PHP (rimane su Altervista)
                const fbRes  = await fetch('ai_get_feedback.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify({ classe: cls, anno_scolastico: anno }),
                });
                const fbData = await fbRes.json();

                if (!fbData.success) {
                    throw new Error(fbData.error || 'Errore lettura feedback.');
                }

                // 2. Chiama il Worker Cloudflare direttamente dal browser
                const groqRes = await fetch(WORKER_URL, {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify({
                        model:       'llama-3.3-70b-versatile',
                        messages:    [{ role: 'user', content: fbData.prompt }],
                        max_tokens:  1024,
                        temperature: 0.4,
                    }),
                });
                const groqData = await groqRes.json();

                if (!groqRes.ok || !groqData.choices?.[0]?.message?.content) {
                    throw new Error(groqData.error?.message || 'Errore risposta AI.');
                }

                const riassunto = groqData.choices[0].message.content.trim();

                // 3. Salva il riassunto nel DB tramite PHP
                const saveRes  = await fetch('ai_save_summary.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify({
                        classe:          cls,
                        riassunto:       riassunto,
                        n_feedback:      fbData.n_feedback,
                        anno_scolastico: anno,
                    }),
                });
                const saveData = await saveRes.json();

                loading.classList.remove('show');

                if (saveData.success || saveData.already_exists) {
                    riassuntiCache[cls] = true;
                    if (btn) {
                        btn.style.display = 'none';
                        const dateSpan = document.createElement('span');
                        dateSpan.style.cssText = 'font-size:12px;color:#888;font-style:italic;';
                        dateSpan.textContent = 'Generato oggi';
                        btn.parentNode.insertBefore(dateSpan, btn);
                    }
                    resultEl.innerHTML = `
                        <div class="ai-result">
                            <div class="ai-result-header">🤖 Riassunto AI · ${fbData.n_feedback} feedback analizzati</div>
                            <div class="ai-result-body md-render">${renderMarkdown(riassunto)}</div>
                        </div>`;
                } else {
                    throw new Error(saveData.error || 'Errore salvataggio.');
                }

            } catch (e) {
                loading.classList.remove('show');
                errEl.textContent = '❌ ' + e.message;
                errEl.classList.add('show');
                btn.textContent = '✨ Genera Riassunto AI';
                btn.disabled    = false;
            }
        }

        // ── CONFRONTO ANNI ────────────────────────────────────────
        const confrontiCache = {};

        async function generaConfronto(cls) {
            const annoSel   = document.getElementById('anno-sel-' + cls);
            const annoPre   = annoSel ? annoSel.value : '';
            const cacheKey  = cls + '_' + annoPre;

            const loading  = document.getElementById('loading-confronto-' + cls);
            const errEl    = document.getElementById('error-confronto-' + cls);
            const resultEl = document.getElementById('result-confronto-' + cls);

            if (confrontiCache[cacheKey]) {
                resultEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                return;
            }

            loading.classList.add('show');
            errEl.classList.remove('show');
            resultEl.innerHTML = '';

            try {
                // Leggi i due riassunti dal server
                const res  = await fetch('ai_get_confronto.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify({ classe: cls, anno_precedente: annoPre }),
                });
                const data = await res.json();
                if (!data.success) throw new Error(data.error || 'Errore lettura riassunti.');

                // Chiama il Worker per generare il confronto
                const groqRes = await fetch(WORKER_URL, {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify({
                        model:       'llama-3.3-70b-versatile',
                        messages:    [{ role: 'user', content: data.prompt }],
                        max_tokens:  1024,
                        temperature: 0.4,
                    }),
                });
                const groqData = await groqRes.json();
                if (!groqRes.ok || !groqData.choices?.[0]?.message?.content) {
                    throw new Error(groqData.error?.message || 'Errore risposta AI.');
                }

                const confronto = groqData.choices[0].message.content.trim();
                confrontiCache[cacheKey] = true;
                loading.classList.remove('show');

                resultEl.innerHTML = `
                    <div class="ai-result" style="margin-top:14px; border-color:#a78bfa; background:linear-gradient(135deg,#f5f3ff,#fff);">
                        <div class="ai-result-header" style="background:#ede9fe; color:#6d28d9; border-color:#a78bfa;">
                            📊 Confronto ${annoPre} → ${data.anno_corrente} · generato da AI
                        </div>
                        <div class="ai-result-body md-render">${renderMarkdown(confronto)}</div>
                    </div>`;

            } catch (e) {
                loading.classList.remove('show');
                errEl.textContent = '❌ ' + e.message;
                errEl.classList.add('show');
            }
        }

        // ── MARKDOWN SEMPLICE ─────────────────────────────────────
        function renderMarkdown(text) {
            return text
                .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                .replace(/^## (.+)$/gm, '<h2>$1</h2>')
                .replace(/^### (.+)$/gm, '<h3>$1</h3>')
                .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.+?)\*/g, '<em>$1</em>')
                .replace(/\n\n/g, '</p><p>')
                .replace(/^(?!<h[23]>)(.+)$/gm, (m) => m.startsWith('<') ? m : m)
                .replace(/(<\/h[23]>)\s*<\/p><p>/g, '$1')
                .replace(/^<\/p><p>/gm, '')
                .replace(/(?:^|\n)(?!<)(.+)/gm, (m, t) => `<p>${t}</p>`)
                .replace(/<p><\/p>/g, '')
                .replace(/<p>(<h[23]>)/g, '$1')
                .replace(/(<\/h[23]>)<\/p>/g, '$1');
        }
        // ── CAMBIO ANNO ───────────────────────────────────────────
        function cambiaAnno(anno) {
            const url = new URL(window.location.href);
            url.searchParams.set('anno', anno);
            window.location.href = url.toString();
        }

        // Evidenzia anno selezionato se non è quello corrente
        const selAnno = document.getElementById('sel-anno');
        if (selAnno && selAnno.value !== '<?= htmlspecialchars($annoCorrente) ?>') {
            selAnno.style.borderColor = '#d97706';
            selAnno.style.background  = '#fffbeb';
        }

        // Render markdown per riassunti già salvati (caricati da PHP)
        document.querySelectorAll('.md-render').forEach(el => {
            if (!el.dataset.rendered) {
                el.innerHTML = renderMarkdown(el.textContent);
                el.dataset.rendered = '1';
            }
        });
    </script>

</body>
</html>
