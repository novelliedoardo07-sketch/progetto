-- ============================================================
--  MIGRATION: RICREA TABELLE CON PK COMPOSITA SU CLASSI
--  Droppa e ricrea classi, insegna, feedback, studenti
--  con la chiave primaria (classe, scuola) su classi.
--  ⚠ TUTTI I DATI ESISTENTI IN QUESTE TABELLE VERRANNO PERSI
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ── 1. Droppa le tabelle nell'ordine giusto (prima le dipendenti) ──

DROP TABLE IF EXISTS `feedback`;
DROP TABLE IF EXISTS `insegna`;
DROP TABLE IF EXISTS `studenti`;
DROP TABLE IF EXISTS `classi`;

-- ── 2. Ricrea classi con PK composita (classe + scuola) ──────

CREATE TABLE `classi` (
  `classe`     VARCHAR(6)  NOT NULL COLLATE utf8mb4_general_ci,
  `sede`       VARCHAR(10) NOT NULL DEFAULT 'SEDE' COLLATE utf8mb4_general_ci,
  `n_studenti` INT         NOT NULL,
  `scuola`     INT         NOT NULL COMMENT 'FK → scuola.id',
  PRIMARY KEY (`classe`, `scuola`),
  CONSTRAINT `fk_classi_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ── 3. Ricrea insegna ─────────────────────────────────────────

CREATE TABLE `insegna` (
  `id`     INT        NOT NULL COMMENT 'FK → prof.id',
  `classe` VARCHAR(6) NOT NULL COLLATE utf8mb4_general_ci,
  `scuola` INT        NOT NULL DEFAULT 1 COMMENT 'FK → scuola.id',
  PRIMARY KEY (`id`, `classe`),
  CONSTRAINT `fk_insegna_classe`
    FOREIGN KEY (`classe`, `scuola`) REFERENCES `classi` (`classe`, `scuola`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_insegna_prof`
    FOREIGN KEY (`id`) REFERENCES `prof` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_insegna_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ── 4. Ricrea studenti ────────────────────────────────────────

CREATE TABLE `studenti` (
  `id`       INT          NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(5)   NOT NULL COLLATE utf8mb4_general_ci,
  `password` VARCHAR(255) DEFAULT NULL COLLATE utf8mb4_general_ci,
  `IsUsed`   TINYINT(1)   NOT NULL DEFAULT 0,
  `classe`   VARCHAR(6)   NOT NULL COLLATE utf8mb4_general_ci,
  `scuola`   INT          NOT NULL DEFAULT 1 COMMENT 'FK → scuola.id',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_studenti_classe`
    FOREIGN KEY (`classe`, `scuola`) REFERENCES `classi` (`classe`, `scuola`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_studenti_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ── 5. Ricrea feedback ────────────────────────────────────────

CREATE TABLE `feedback` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `idUser`    INT          NOT NULL,
  `classe`    VARCHAR(6)   NOT NULL COLLATE utf8mb4_general_ci,
  `scuola`    INT          NOT NULL DEFAULT 1 COMMENT 'FK → scuola.id',
  `idProf`    INT          NOT NULL,
  `categoria` ENUM('professionale','umano','altro') NOT NULL COLLATE utf8mb4_general_ci,
  `positivo`  TEXT         NOT NULL COLLATE utf8mb4_general_ci,
  `negativo`  TEXT         NOT NULL COLLATE utf8mb4_general_ci,
  `creato_il` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_fb_classe`
    FOREIGN KEY (`classe`, `scuola`) REFERENCES `classi` (`classe`, `scuola`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fb_prof`
    FOREIGN KEY (`idProf`) REFERENCES `prof` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fb_user`
    FOREIGN KEY (`idUser`) REFERENCES `studenti` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_feedback_scuola`
    FOREIGN KEY (`scuola`) REFERENCES `scuola` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ── VERIFICA ─────────────────────────────────────────────────
SELECT 'classi'   AS tabella, COUNT(*) AS righe FROM classi
UNION ALL
SELECT 'insegna',   COUNT(*) FROM insegna
UNION ALL
SELECT 'studenti',  COUNT(*) FROM studenti
UNION ALL
SELECT 'feedback',  COUNT(*) FROM feedback;
