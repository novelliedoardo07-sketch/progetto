<?php
require_once 'auth_check.php';

if ($_SESSION['ruolo'] !== 'studente') {
    header('Location: dashboard_prof.php');
    exit;
}

$idUser   = $_SESSION['user_id'];
$classe   = $_SESSION['classe'];
$idScuola = (int)$_SESSION['scuola'];

require_once 'db.php'; // fornisce $pdo e $scuola
require_once 'crypto.php';

$categorie = [
    'professionale' => [
        'label' => '1. Lato Professionale',
        'icona' => '📚',
        'desc'  => 'Valuta la preparazione, la chiarezza nella spiegazione e la competenza didattica del professore.',
    ],
    'umano' => [
        'label' => '2. Lato Umano',
        'icona' => '🤝',
        'desc'  => "Valuta la disponibilità, l'empatia e il rapporto con gli studenti.",
    ],
    'altro' => [
        'label' => '3. Altro',
        'icona' => '💬',
        'desc'  => 'Qualsiasi altra considerazione che vuoi condividere sul professore.',
    ],
];

$successo = '';
$errore   = '';

// ── POST ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idProf = filter_input(INPUT_POST, 'idProf', FILTER_VALIDATE_INT);

    if (!$idProf) {
        $errore = 'Seleziona un professore prima di inviare.';
    } else {
        // Verifica che il prof appartenga alla stessa scuola
        $chkProf = $pdo->prepare("SELECT id FROM prof WHERE id = ? AND scuola = ?");
        $chkProf->execute([$idProf, $idScuola]);
        if (!$chkProf->fetch()) {
            $errore = 'Professore non valido per questa scuola.';
        } else {
            $check = $pdo->prepare("SELECT COUNT(*) FROM feedback WHERE idUser = ? AND idProf = ?");
            $check->execute([$idUser, $idProf]);

            if ($check->fetchColumn() > 0) {
                $errore = 'Hai già valutato questo professore.';
            } else {
                $campiOk = true;
                foreach (array_keys($categorie) as $cat) {
                    if (empty(trim($_POST["pos_$cat"] ?? '')) || empty(trim($_POST["neg_$cat"] ?? ''))) {
                        $campiOk = false;
                        break;
                    }
                }

                if (!$campiOk) {
                    $errore = 'Compila tutti i campi positivi e negativi per ogni categoria.';
                } else {
                    $annoScolastico = $scuola['anno_scolastico'] ?? '2024-2025';
                    $insert = $pdo->prepare(
                        "INSERT INTO feedback (idUser, classe, idProf, categoria, positivo, negativo, scuola, anno_scolastico)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                    );
                    foreach (array_keys($categorie) as $cat) {
                        $insert->execute([
                            $idUser, $classe, $idProf, $cat,
                            encrypt(trim($_POST["pos_$cat"])),
                            encrypt(trim($_POST["neg_$cat"])),
                            $idScuola,
                            $annoScolastico,
                        ]);
                    }
                    $pdo->prepare("UPDATE studenti SET IsUsed = 1 WHERE id = ?")->execute([$idUser]);
                    $_SESSION['is_used'] = 1;
                    $successo = 'Valutazione inviata con successo. Grazie per il tuo feedback!';
                }
            }
        }
    }
}

// ── Professori della classe (filtrati per scuola) ─────────────
$stmtProf = $pdo->prepare(
    "SELECT p.id, p.nome, p.cognome
     FROM prof p
     INNER JOIN insegna i ON i.id = p.id
     WHERE i.classe = ? AND i.scuola = ?
     ORDER BY p.cognome, p.nome"
);
$stmtProf->execute([$classe, $idScuola]);
$professori = $stmtProf->fetchAll(PDO::FETCH_ASSOC);

$annoScolastico = $scuola['anno_scolastico'] ?? '2024-2025';
$stmtVotati = $pdo->prepare("SELECT DISTINCT idProf FROM feedback WHERE idUser = ? AND anno_scolastico = ?");
$stmtVotati->execute([$idUser, $annoScolastico]);
$profVotati = $stmtVotati->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valutazione Professori – <?= htmlspecialchars($scuola['nome']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="styles_unified.css">
</head>
<body>

    <img src="<?= htmlspecialchars($scuola['logo']) ?>" alt="logo scuola" id="logo1">
    <button id="homeBtn" onclick="window.location.href='logout.php'">Esci</button>

    <header class="page-hero">
        <h1>Valutazione Professori</h1>
        <h2><?= htmlspecialchars($scuola['nome']) ?> – <?= htmlspecialchars($scuola['citta']) ?></h2>
    </header>

    <div id="info-studente">
        Benvenuto <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
        &nbsp;|&nbsp; Classe: <strong><?= htmlspecialchars($classe) ?></strong>
    </div>

    <div id="valutazione">

        <?php if ($successo): ?>
            <div id="successo-msg"><?= htmlspecialchars($successo) ?></div>
        <?php endif; ?>

        <div id="errore"><?php if ($errore) echo htmlspecialchars($errore); ?></div>

        <?php if (empty($professori)): ?>
            <p style="text-align:center; color:#888; margin-top:20px;">
                Nessun professore associato alla tua classe (<?= htmlspecialchars($classe) ?>).<br>
                Contatta l'amministratore.
            </p>
        <?php else: ?>

        <form method="POST" action="valutazione.php" id="formValutazione">

            <label for="idProf">Seleziona il professore da valutare</label>
            <select name="idProf" id="idProf" required onchange="aggiornaStato()">
                <option value="">-- scegli --</option>
                <?php foreach ($professori as $prof): ?>
                    <?php $giàVotato = in_array($prof['id'], $profVotati); ?>
                    <option value="<?= $prof['id'] ?>"
                        <?= (isset($_POST['idProf']) && $_POST['idProf'] == $prof['id']) ? 'selected' : '' ?>
                        <?= $giàVotato ? 'disabled' : '' ?>>
                        <?= htmlspecialchars($prof['cognome'] . ' ' . $prof['nome']) ?>
                        <?= $giàVotato ? ' ✓ già valutato' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <div id="categorie-container" style="display:none;">
            <?php foreach ($categorie as $chiave => $info): ?>
            <div class="categoria-card">
                <div class="categoria-titolo"><?= $info['icona'] ?> <?= $info['label'] ?></div>
                <div class="categoria-desc"><?= htmlspecialchars($info['desc']) ?></div>

                <div class="campo-group">
                    <label for="pos_<?= $chiave ?>">👍 Cosa di positivo?</label>
                    <textarea class="campo-pos" name="pos_<?= $chiave ?>" id="pos_<?= $chiave ?>"
                        placeholder="Scrivi un aspetto positivo..." maxlength="500"
                        oninput="aggiornaContatore(this, 'cnt_pos_<?= $chiave ?>')"
                    ><?= htmlspecialchars($_POST["pos_$chiave"] ?? '') ?></textarea>
                    <div class="char-count" id="cnt_pos_<?= $chiave ?>">0 / 500</div>
                </div>

                <div class="campo-group">
                    <label for="neg_<?= $chiave ?>">👎 Cosa di negativo?</label>
                    <textarea class="campo-neg" name="neg_<?= $chiave ?>" id="neg_<?= $chiave ?>"
                        placeholder="Scrivi un aspetto negativo..." maxlength="500"
                        oninput="aggiornaContatore(this, 'cnt_neg_<?= $chiave ?>')"
                    ><?= htmlspecialchars($_POST["neg_$chiave"] ?? '') ?></textarea>
                    <div class="char-count" id="cnt_neg_<?= $chiave ?>">0 / 500</div>
                </div>
            </div>
            <?php endforeach; ?>
            </div>

            <button type="submit" id="btnInvia" style="display:none;">Invia valutazione</button>
        </form>

        <?php if (!empty($profVotati)): ?>
            <p id="messaggio">
                Hai già valutato <?= count($profVotati) ?> su <?= count($professori) ?> professori.
            </p>
        <?php endif; ?>
        <?php endif; ?>

    </div>

    <div id="contatti">
        <h2>I nostri contatti</h2>
        <?php foreach ($scuola['contatti_arr'] as $c): ?>
            <h4><?= htmlspecialchars($c) ?></h4>
        <?php endforeach; ?>
    </div>

    <script>
        const stato = {};
        const campi = [
            'pos_professionale','neg_professionale',
            'pos_umano','neg_umano',
            'pos_altro','neg_altro'
        ];

        function salvaPerProf(id) {
            if (!id) return;
            if (!stato[id]) stato[id] = {};
            campi.forEach(n => { const el = document.getElementById(n); if (el) stato[id][n] = el.value; });
        }

        function ripristinaProf(id) {
            const dati = stato[id] || {};
            campi.forEach(n => {
                const el = document.getElementById(n);
                if (el) { el.value = dati[n] || ''; aggiornaContatore(el, 'cnt_' + n); }
            });
        }

        function aggiornaVisibilita(id) {
            const mostra = id !== '';
            document.getElementById('categorie-container').style.display = mostra ? 'flex' : 'none';
            document.getElementById('btnInvia').style.display             = mostra ? 'block' : 'none';
        }

        const sel = document.getElementById('idProf');
        if (sel) {
            sel.dataset.prev = sel.value;
            aggiornaVisibilita(sel.value);
            sel.addEventListener('change', function () {
                salvaPerProf(this.dataset.prev);
                this.dataset.prev = this.value;
                ripristinaProf(this.value);
                aggiornaVisibilita(this.value);
            });
        }

        function aggiornaContatore(el, cntId) {
            const cnt = document.getElementById(cntId);
            if (cnt) cnt.textContent = el.value.length + ' / 500';
        }

        campi.forEach(n => {
            const el = document.getElementById(n);
            if (!el) return;
            el.addEventListener('input', function () {
                aggiornaContatore(this, 'cnt_' + n);
                const id = document.getElementById('idProf').value;
                if (id) { if (!stato[id]) stato[id] = {}; stato[id][n] = this.value; }
            });
        });

        document.querySelectorAll('textarea').forEach(ta => {
            aggiornaContatore(ta, 'cnt_' + ta.id);
        });
    </script>

</body>
</html>
