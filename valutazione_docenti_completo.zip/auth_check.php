<?php
// auth_check.php – includi in OGNI pagina protetta
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Garantisce che scuola sia sempre in sessione (eccetto superadmin)
if (!isset($_SESSION['scuola']) && $_SESSION['ruolo'] !== 'superadmin') {
    header('Location: login.php');
    exit;
}

function requireRuolo(string $ruolo): void {
    if ($_SESSION['ruolo'] !== $ruolo) {
        http_response_code(403);
        die('Accesso negato.');
    }
}
