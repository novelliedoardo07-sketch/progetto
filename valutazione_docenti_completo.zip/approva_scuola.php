<?php
// approva_scuola.php
// Gestisce approvazione/rifiuto via link email OPPURE via POST dal pannello superadmin

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('Errore di connessione al database.');
}

define('CHARS', 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789');

function randomStr(int $len): string {
    $chars = CHARS; $result = ''; $max = strlen($chars) - 1;
    for ($i = 0; $i < $len; $i++) $result .= $chars[random_int(0, $max)];
    return $result;
}

function generaCredenziali(int $totale): array {
    $credenziali = []; $usedUser = []; $usedPass = []; $tentativi = 0;
    while (count($credenziali) < $totale && $tentativi < $totale * 20) {
        $tentativi++; $u = randomStr(3); $p = randomStr(3);
        if (isset($usedUser[$u]) || isset($usedPass[$p])) continue;
        $usedUser[$u] = true; $usedPass[$p] = true;
        $credenziali[] = ['username' => $u, 'password' => $p];
    }
    while (count($credenziali) < $totale) {
        $u = randomStr(4); $p = randomStr(4);
        if (isset($usedUser[$u])) continue;
        $usedUser[$u] = true;
        $credenziali[] = ['username' => $u, 'password' => $p];
    }
    return $credenziali;
}

function creaScuola(PDO $pdo, array $r): int {
    $classi         = json_decode($r['classi_json'], true);
    $totStudenti    = array_sum(array_column($classi, 'n_studenti'));
    $allCredenziali = generaCredenziali($totStudenti);

    $pdo->beginTransaction();

    $pdo->prepare(
        "INSERT INTO scuola (nome, citta, logo, contatti, codice_registrazione, anno_scolastico)
         VALUES (?, ?, ?, ?, ?, '2024-2025')"
    )->execute([$r['nome'], $r['citta'], $r['logo'], $r['contatti'], $r['codice_reg']]);
    $idScuola = (int)$pdo->lastInsertId();

    $pdo->prepare(
        "INSERT INTO amministratori (username, password, scuola) VALUES (?, ?, ?)"
    )->execute([$r['admin_username'], $r['admin_password'], $idScuola]);

    $stmtClasse   = $pdo->prepare("INSERT INTO classi (classe, sede, n_studenti, scuola) VALUES (?, ?, ?, ?)");
    $stmtStudente = $pdo->prepare("INSERT INTO studenti (username, password, IsUsed, classe, scuola) VALUES (?, ?, 0, ?, ?)");

    $credIdx = 0;
    foreach ($classi as $cl) {
        $classe    = strtoupper(trim($cl['classe']));
        $sede      = strtoupper(trim($cl['sede']));
        $nStudenti = (int)$cl['n_studenti'];
        $stmtClasse->execute([$classe, $sede, $nStudenti, $idScuola]);
        for ($i = 0; $i < $nStudenti; $i++) {
            $cred = $allCredenziali[$credIdx++];
            $stmtStudente->execute([$cred['username'], $cred['password'], $classe, $idScuola]);
        }
    }

    $pdo->commit();
    return $idScuola;
}

// ── GESTIONE VIA POST (dal pannello superadmin) ───────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    session_start();
    if (!isset($_SESSION['ruolo']) || $_SESSION['ruolo'] !== 'superadmin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Accesso negato.']);
        exit;
    }

    $id     = (int)($_POST['id']     ?? 0);
    $azione = trim($_POST['azione']  ?? '');

    if (!$id || !in_array($azione, ['approva', 'rifiuta'])) {
        echo json_encode(['success' => false, 'error' => 'Dati non validi.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM richieste_scuola WHERE id = ? AND stato = 'in_attesa' LIMIT 1");
    $stmt->execute([$id]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$r) {
        echo json_encode(['success' => false, 'error' => 'Richiesta non trovata o già gestita.']);
        exit;
    }

    try {
        if ($azione === 'approva') {
            creaScuola($pdo, $r);
        }
        $pdo->prepare(
            "UPDATE richieste_scuola SET stato = ?, gestita_il = NOW() WHERE id = ?"
        )->execute([$azione === 'approva' ? 'approvata' : 'rifiutata', $id]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Errore: ' . $e->getMessage()]);
    }
    exit;
}

// ── GESTIONE VIA LINK EMAIL (GET) ────────────────────────────
$token  = trim($_GET['token']  ?? '');
$azione = trim($_GET['azione'] ?? '');

if (!$token || !in_array($azione, ['approva', 'rifiuta'])) {
    die('<p>Link non valido.</p>');
}

$stmt = $pdo->prepare("SELECT * FROM richieste_scuola WHERE token = ? LIMIT 1");
$stmt->execute([$token]);
$r = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$r) {
    die('<p>Richiesta non trovata.</p>');
}

if ($r['stato'] !== 'in_attesa') {
    $statoLabel = $r['stato'] === 'approvata' ? '✅ già approvata' : '❌ già rifiutata';
    die("<p>Questa richiesta è {$statoLabel}.</p>");
}

$esito  = '';
$errore = '';

try {
    if ($azione === 'approva') {
        creaScuola($pdo, $r);
        $pdo->prepare("UPDATE richieste_scuola SET stato = 'approvata', gestita_il = NOW() WHERE id = ?")->execute([$r['id']]);
        $esito = "✅ Scuola <strong>" . htmlspecialchars($r['nome']) . "</strong> approvata e creata con successo.";
    } else {
        $pdo->prepare("UPDATE richieste_scuola SET stato = 'rifiutata', gestita_il = NOW() WHERE id = ?")->execute([$r['id']]);
        $esito = "❌ Richiesta per <strong>" . htmlspecialchars($r['nome']) . "</strong> rifiutata.";
    }
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    $errore = "Errore durante l'operazione: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approvazione Scuola</title>
    <link rel="stylesheet" href="styles_unified.css">
</head>
<body>
    <header class="page-hero">
        <h1>Valutazione Docenti</h1>
        <h2>Approvazione Scuola</h2>
    </header>
    <div style="max-width:520px; margin:40px auto; background:white; border-radius:12px; padding:32px; box-shadow:0 4px 20px rgba(0,0,0,.1); text-align:center;">
        <?php if ($esito): ?>
            <p style="font-size:18px; line-height:1.6;"><?= $esito ?></p>
            <a href="dashboard_superadmin.php" style="display:inline-block; margin-top:20px; padding:12px 28px; background:#1a5fa8; color:white; border-radius:8px; text-decoration:none; font-weight:700;">Vai al pannello Super Admin</a>
        <?php else: ?>
            <p style="color:#cc0000; font-size:16px;"><?= htmlspecialchars($errore) ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
