-- ============================================================
--  MIGRATION: COLONNE CIFRATE PER FEEDBACK E RIASSUNTI_AI
--  I dati cifrati con AES-256-CBC sono più lunghi del testo
--  originale, quindi allarghiamo le colonne a MEDIUMTEXT.
--  Da eseguire UNA VOLTA sul database.
-- ============================================================

-- feedback: allarga positivo e negativo
ALTER TABLE `feedback`
  MODIFY COLUMN `positivo` MEDIUMTEXT NOT NULL,
  MODIFY COLUMN `negativo` MEDIUMTEXT NOT NULL;

-- riassunti_ai: allarga riassunto
ALTER TABLE `riassunti_ai`
  MODIFY COLUMN `riassunto` MEDIUMTEXT NOT NULL;

-- VERIFICA
SHOW COLUMNS FROM feedback LIKE 'positivo';
SHOW COLUMNS FROM feedback LIKE 'negativo';
SHOW COLUMNS FROM riassunti_ai LIKE 'riassunto';
