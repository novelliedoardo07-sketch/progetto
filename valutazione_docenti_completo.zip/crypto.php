<?php
// crypto.php  –  cifratura/decifratura AES-256-CBC
// Includi questo file ovunque serve cifrare o decifrare.
// La chiave NON deve mai finire nel database.

// ── CHIAVE DI CIFRATURA ───────────────────────────────────────
// Stringa segreta di almeno 32 caratteri — CAMBIALA con qualcosa di tuo
// e non condividerla mai. Se la perdi, i dati esistenti non sono più leggibili.
define('CRYPTO_KEY', 'CAMBIA_QUESTA_CHIAVE_CON_32_CARATTERI_CASUALI!');

// ── CIFRA ─────────────────────────────────────────────────────
function encrypt(string $plaintext): string {
    $key    = substr(hash('sha256', CRYPTO_KEY, true), 0, 32);
    $iv     = random_bytes(16);
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv) . '::' . $cipher;
}

// ── DECIFRA ───────────────────────────────────────────────────
function decrypt(string $encrypted): string {
    if (!str_contains($encrypted, '::')) {
        // Dato non cifrato (compatibilità con dati vecchi)
        return $encrypted;
    }
    $key   = substr(hash('sha256', CRYPTO_KEY, true), 0, 32);
    [$iv64, $cipher] = explode('::', $encrypted, 2);
    $iv     = base64_decode($iv64);
    $result = openssl_decrypt($cipher, 'AES-256-CBC', $key, 0, $iv);
    return $result !== false ? $result : '[errore decifratura]';
}
