<?php
require_once 'auth_check.php';
requireRuolo('superadmin');

// db.php richiede $_SESSION['scuola'] — per superadmin usiamo una connessione diretta
$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('Errore di connessione al database.');
}

$msg   = '';
$error = '';

// ── POST ACTIONS ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── SCUOLA: modifica nome/città/logo/anno ─────────────────
    if ($action === 'update_scuola') {
        $id    = (int)($_POST['id']    ?? 0);
        $nome  = trim($_POST['nome']   ?? '');
        $citta = trim($_POST['citta']  ?? '');
        $logo  = trim($_POST['logo']   ?? 'logo.png');
        $anno  = trim($_POST['anno_scolastico'] ?? '');
        if ($id && $nome && $citta && preg_match('/^\d{4}-\d{4}$/', $anno)) {
            $pdo->prepare("UPDATE scuola SET nome=?, citta=?, logo=?, anno_scolastico=? WHERE id=?")
                ->execute([$nome, $citta, $logo, $anno, $id]);
            $msg = "Scuola aggiornata.";
        } else {
            $error = 'Dati non validi.';
        }

    // ── SCUOLA: elimina ───────────────────────────────────────
    } elseif ($action === 'del_scuola') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            foreach (['feedback','insegna','studenti','classi','prof','amministratori','riassunti_ai'] as $t) {
                $pdo->prepare("DELETE FROM `{$t}` WHERE scuola = ?")->execute([$id]);
            }
            $pdo->prepare("DELETE FROM scuola WHERE id = ?")->execute([$id]);
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
            $msg = "Scuola eliminata con tutti i dati collegati.";
        }

    // ── SCUOLA: aggiorna anno scolastico a tutte ──────────────
    } elseif ($action === 'update_anno_globale') {
        $anno = trim($_POST['anno_scolastico'] ?? '');
        if (preg_match('/^\d{4}-\d{4}$/', $anno)) {
            $pdo->beginTransaction();

            // Aggiorna anno per tutte le scuole
            $pdo->prepare("UPDATE scuola SET anno_scolastico = ?")->execute([$anno]);

            // Rigenera credenziali di tutti gli studenti di tutte le scuole
            $studenti = $pdo->query("SELECT id FROM studenti");
            $updStud  = $pdo->prepare("UPDATE studenti SET username = ?, password = ?, IsUsed = 0 WHERE id = ?");

            $usedUser = []; $usedPass = [];
            $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
            $max   = strlen($chars) - 1;
            $randomStr = function(int $len) use ($chars, $max): string {
                $r = '';
                for ($i = 0; $i < $len; $i++) $r .= $chars[random_int(0, $max)];
                return $r;
            };

            foreach ($studenti->fetchAll(PDO::FETCH_ASSOC) as $s) {
                do { $u = $randomStr(3); } while (isset($usedUser[$u]));
                do { $p = $randomStr(3); } while (isset($usedPass[$p]));
                $usedUser[$u] = true; $usedPass[$p] = true;
                $updStud->execute([$u, $p, $s['id']]);
            }

            $pdo->commit();
            $nStudenti = count($usedUser);
            // Ricarica dati scuole per riflettere il nuovo anno nella vista
            $scuole = $pdo->query(
                "SELECT s.id, s.nome, s.citta, s.logo, s.anno_scolastico,
                        COUNT(DISTINCT c.classe) AS n_classi,
                        COUNT(DISTINCT st.id)    AS n_studenti,
                        COUNT(DISTINCT p.id)     AS n_prof,
                        COUNT(DISTINCT a.id)     AS n_admin
                 FROM scuola s
                 LEFT JOIN classi         c  ON c.scuola  = s.id
                 LEFT JOIN studenti       st ON st.scuola = s.id
                 LEFT JOIN prof           p  ON p.scuola  = s.id
                 LEFT JOIN amministratori a  ON a.scuola  = s.id
                 GROUP BY s.id ORDER BY s.nome"
            )->fetchAll(PDO::FETCH_ASSOC);
            $msg = "Anno aggiornato a {$anno} per tutte le scuole. Credenziali rigenerate per {$nStudenti} studenti.";
        } else {
            $error = 'Formato non valido. Usa es. 2025-2026.';
        }

    // ── ADMIN: aggiungi ───────────────────────────────────────
    } elseif ($action === 'add_admin') {
        $idScuola = (int)($_POST['id_scuola'] ?? 0);
        $username = trim($_POST['username']   ?? '');
        $password = trim($_POST['password']   ?? '');
        if ($idScuola && $username && $password) {
            $chk = $pdo->prepare("SELECT id FROM amministratori WHERE username = ? AND scuola = ?");
            $chk->execute([$username, $idScuola]);
            if ($chk->fetch()) {
                $error = 'Username già in uso per questa scuola.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $pdo->prepare("INSERT INTO amministratori (username, password, scuola) VALUES (?,?,?)")
                    ->execute([$username, $hash, $idScuola]);
                $msg = "Admin [{$username}] aggiunto.";
            }
        } else {
            $error = 'Compila tutti i campi.';
        }

    // ── ADMIN: elimina ────────────────────────────────────────
    } elseif ($action === 'del_admin') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $pdo->prepare("DELETE FROM amministratori WHERE id = ?")->execute([$id]);
            $msg = 'Admin eliminato.';
        }

    // ── ADMIN: reset password ─────────────────────────────────
    } elseif ($action === 'reset_admin_pass') {
        $id   = (int)($_POST['id']       ?? 0);
        $pass = trim($_POST['password']  ?? '');
        if ($id && $pass) {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE amministratori SET password = ? WHERE id = ?")->execute([$hash, $id]);
            $msg = 'Password admin aggiornata.';
        }

    // ── PROF: elimina ─────────────────────────────────────────
    } elseif ($action === 'del_prof') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $pdo->prepare("DELETE FROM prof WHERE id = ?")->execute([$id]);
            $msg = 'Professore eliminato.';
        }

    // ── PROF: reset password ──────────────────────────────────
    } elseif ($action === 'reset_prof_pass') {
        $id   = (int)($_POST['id']      ?? 0);
        $pass = trim($_POST['password'] ?? '');
        if ($id && $pass) {
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE prof SET password = ? WHERE id = ?")->execute([$hash, $id]);
            $msg = 'Password professore aggiornata.';
        }
    }
}

// ── DATI ─────────────────────────────────────────────────────
$scuole = $pdo->query(
    "SELECT s.id, s.nome, s.citta, s.logo, s.anno_scolastico,
            COUNT(DISTINCT c.classe) AS n_classi,
            COUNT(DISTINCT st.id)    AS n_studenti,
            COUNT(DISTINCT p.id)     AS n_prof,
            COUNT(DISTINCT a.id)     AS n_admin
     FROM scuola s
     LEFT JOIN classi         c  ON c.scuola  = s.id
     LEFT JOIN studenti       st ON st.scuola = s.id
     LEFT JOIN prof           p  ON p.scuola  = s.id
     LEFT JOIN amministratori a  ON a.scuola  = s.id
     GROUP BY s.id ORDER BY s.nome"
)->fetchAll(PDO::FETCH_ASSOC);

$admins = $pdo->query(
    "SELECT a.id, a.username, a.scuola, s.nome AS nome_scuola
     FROM amministratori a
     JOIN scuola s ON s.id = a.scuola
     ORDER BY s.nome, a.username"
)->fetchAll(PDO::FETCH_ASSOC);

$profs = $pdo->query(
    "SELECT p.id, p.nome, p.cognome, p.username, p.scuola, s.nome AS nome_scuola,
            GROUP_CONCAT(i.classe ORDER BY i.classe SEPARATOR ', ') AS classi
     FROM prof p
     JOIN scuola s ON s.id = p.scuola
     LEFT JOIN insegna i ON i.id = p.id AND i.scuola = p.scuola
     GROUP BY p.id ORDER BY s.nome, p.cognome, p.nome"
)->fetchAll(PDO::FETCH_ASSOC);

$activeTab = 'scuole';
if (!empty($_POST['action'])) {
    $a = $_POST['action'];
    if (str_contains($a, 'scuola') || str_contains($a, 'anno')) $activeTab = 'scuole';
    elseif (str_contains($a, 'admin'))                           $activeTab = 'admin';
    elseif (str_contains($a, 'prof'))                            $activeTab = 'prof';
}
if (isset($_GET['tab'])) $activeTab = $_GET['tab'];

$richieste = $pdo->query(
    "SELECT * FROM richieste_scuola ORDER BY creato_il DESC"
)->fetchAll(PDO::FETCH_ASSOC);
$nInAttesa = count(array_filter($richieste, fn($r) => $r['stato'] === 'in_attesa'));
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Super Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        .admin-wrap { max-width: 1200px; margin: 0 auto; padding: 0 20px 60px; }
        .tabs { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:28px; }
        .tab-btn { font-family:'Barlow Condensed',sans-serif; font-size:15px; font-weight:700; letter-spacing:.5px; padding:9px 22px; border-radius:100px; border:2px solid var(--grigio-brd); background:white; color:#888; cursor:pointer; transition:all .2s; }
        .tab-btn:hover { border-color:var(--blu); color:var(--blu); }
        .tab-btn.active { background:var(--blu); border-color:var(--blu); color:white; box-shadow:0 4px 14px rgba(0,0,205,.25); }
        .tab-panel { display:none; }
        .tab-panel.active { display:block; }
        .card { background:white; border:1px solid var(--grigio-brd); border-radius:var(--radius-lg); padding:24px 28px; box-shadow:var(--shadow-md); margin-bottom:22px; }
        .card h3 { font-family:'Barlow Condensed',sans-serif; font-size:20px; font-weight:800; color:var(--blu); margin-bottom:18px; padding-bottom:10px; border-bottom:2px solid var(--blu-light); }
        .form-row { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
        .form-row input, .form-row select { flex:1; min-width:140px; margin:0; padding:9px 13px; font-size:14px; }
        .form-row button { width:auto; padding:9px 22px; font-size:14px; margin:0; flex-shrink:0; }
        .data-table { width:100%; border-collapse:collapse; font-size:14px; }
        .data-table th { text-align:left; padding:10px 12px; background:var(--grigio-bg); color:#555; font-family:'Barlow Condensed',sans-serif; font-size:13px; font-weight:700; letter-spacing:.5px; text-transform:uppercase; border-bottom:2px solid var(--grigio-brd); }
        .data-table td { padding:10px 12px; border-bottom:1px solid var(--grigio-brd); vertical-align:middle; }
        .data-table tr:last-child td { border-bottom:none; }
        .data-table tr:hover td { background:var(--grigio-bg); }
        .stat-pill { display:inline-block; background:var(--blu-light); color:var(--blu); border-radius:100px; padding:3px 10px; font-size:12px; font-weight:700; margin:2px; }
        .btn-sm { width:auto; padding:5px 14px; font-size:13px; margin:0; }
        .btn-danger { background:#dc2626; }
        .btn-danger:hover { background:#b91c1c; }
        .btn-warn { background:#d97706; }
        .btn-warn:hover { background:#b45309; }
        .msg-ok  { background:#dcfce7; color:#166534; border:1px solid #86efac; border-radius:var(--radius-sm); padding:12px 16px; margin-bottom:20px; font-weight:600; }
        .msg-err { background:#fee2e2; color:#991b1b; border:1px solid #fca5a5; border-radius:var(--radius-sm); padding:12px 16px; margin-bottom:20px; font-weight:600; }
        .modal-bg { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:1000; align-items:center; justify-content:center; }
        .modal-bg.open { display:flex; }
        .modal { background:white; border-radius:var(--radius-lg); padding:30px; max-width:460px; width:90%; box-shadow:0 20px 60px rgba(0,0,0,.3); }
        .modal h4 { font-family:'Barlow Condensed',sans-serif; font-size:20px; font-weight:800; color:var(--blu); margin-bottom:16px; }
        .modal input, .modal select { margin-bottom:12px; }
        .super-badge { display:inline-block; background:#7c3aed; color:white; border-radius:100px; padding:3px 12px; font-size:12px; font-weight:700; margin-left:8px; }
        @media(max-width:640px) { .form-row { flex-direction:column; } }
    </style>
</head>
<body>

    <button id="homeBtn" onclick="window.location.href='logout.php'">Esci</button>

    <header class="page-hero">
        <h1>Super Admin <span class="super-badge">⚡ SUPER</span></h1>
        <h2>Pannello di controllo globale</h2>
    </header>

    <div class="admin-wrap">

        <?php if ($msg):  ?><div class="msg-ok">✅ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg-err">❌ <?= htmlspecialchars($error) ?></div><?php endif; ?>

        <div class="tabs">
            <button class="tab-btn <?= $activeTab==='scuole' ? 'active':'' ?>" onclick="showTab('scuole',this)">🏫 Scuole</button>
            <button class="tab-btn <?= $activeTab==='admin'  ? 'active':'' ?>" onclick="showTab('admin',this)">👤 Amministratori</button>
            <button class="tab-btn <?= $activeTab==='prof'   ? 'active':'' ?>" onclick="showTab('prof',this)">👨‍🏫 Professori</button>
        </div>

        <!-- ══ TAB SCUOLE ════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab==='scuole'?'active':'' ?>" id="tab-scuole">

            <!-- Anno globale -->
            <div class="card">
                <h3>📅 Aggiorna Anno Scolastico — Tutte le Scuole</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_anno_globale">
                    <div class="form-row">
                        <input type="text" name="anno_scolastico" placeholder="Es. 2025-2026" pattern="\d{4}-\d{4}" required>
                        <button type="submit">Aggiorna Tutte</button>
                    </div>
                </form>
            </div>

            <!-- Lista scuole -->
            <div class="card">
                <h3>🏫 Scuole registrate (<?= count($scuole) ?>)</h3>
                <?php if (empty($scuole)): ?>
                    <p style="color:#888;">Nessuna scuola registrata.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Scuola</th><th>Statistiche</th><th>Anno</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($scuole as $s): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($s['nome']) ?></strong><br>
                                <span style="font-size:12px; color:#888;"><?= htmlspecialchars($s['citta']) ?></span>
                            </td>
                            <td>
                                <span class="stat-pill">📋 <?= $s['n_classi'] ?> classi</span>
                                <span class="stat-pill">🎒 <?= $s['n_studenti'] ?> studenti</span>
                                <span class="stat-pill">👨‍🏫 <?= $s['n_prof'] ?> prof</span>
                                <span class="stat-pill">👤 <?= $s['n_admin'] ?> admin</span>
                            </td>
                            <td><code><?= htmlspecialchars($s['anno_scolastico']) ?></code></td>
                            <td style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button class="btn-sm btn-warn" onclick="openEditScuola(<?= htmlspecialchars(json_encode($s)) ?>)">✏️ Modifica</button>
                                <form method="POST" onsubmit="return confirm('Eliminare la scuola <?= htmlspecialchars($s['nome'], ENT_QUOTES) ?> e TUTTI i dati? Questa azione è irreversibile.');" style="display:inline">
                                    <input type="hidden" name="action" value="del_scuola">
                                    <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                    <button type="submit" class="btn-sm btn-danger">🗑 Elimina</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB ADMIN ═════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab==='admin'?'active':'' ?>" id="tab-admin">

            <div class="card">
                <h3>➕ Aggiungi Amministratore</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_admin">
                    <div class="form-row">
                        <select name="id_scuola" required>
                            <option value="">— Scuola —</option>
                            <?php foreach ($scuole as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text"     name="username" placeholder="Username *" required>
                        <input type="password" name="password" placeholder="Password *" required>
                        <button type="submit">Aggiungi</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <h3>👤 Amministratori (<?= count($admins) ?>)</h3>
                <?php if (empty($admins)): ?>
                    <p style="color:#888;">Nessun amministratore.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Username</th><th>Scuola</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($admins as $a): ?>
                        <tr>
                            <td><code><?= htmlspecialchars($a['username']) ?></code></td>
                            <td><?= htmlspecialchars($a['nome_scuola']) ?></td>
                            <td style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button class="btn-sm btn-warn" onclick="openResetPass('admin', <?= $a['id'] ?>, '<?= htmlspecialchars($a['username'], ENT_QUOTES) ?>')">🔑 Reset pw</button>
                                <form method="POST" onsubmit="return confirm('Eliminare l\'admin <?= htmlspecialchars($a['username'], ENT_QUOTES) ?>?');" style="display:inline">
                                    <input type="hidden" name="action" value="del_admin">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <button type="submit" class="btn-sm btn-danger">🗑 Elimina</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB PROF ══════════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab==='prof'?'active':'' ?>" id="tab-prof">
            <div class="card">
                <h3>👨‍🏫 Professori (<?= count($profs) ?>)</h3>
                <?php if (empty($profs)): ?>
                    <p style="color:#888;">Nessun professore.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Nome</th><th>Username</th><th>Scuola</th><th>Classi</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($profs as $p): ?>
                        <tr>
                            <td><?= htmlspecialchars($p['cognome'] . ' ' . $p['nome']) ?></td>
                            <td><code><?= htmlspecialchars($p['username']) ?></code></td>
                            <td style="font-size:13px;"><?= htmlspecialchars($p['nome_scuola']) ?></td>
                            <td style="font-size:12px; color:#666;"><?= htmlspecialchars($p['classi'] ?? '—') ?></td>
                            <td style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button class="btn-sm btn-warn" onclick="openResetPass('prof', <?= $p['id'] ?>, '<?= htmlspecialchars($p['username'], ENT_QUOTES) ?>')">🔑 Reset pw</button>
                                <form method="POST" onsubmit="return confirm('Eliminare il prof <?= htmlspecialchars($p['username'], ENT_QUOTES) ?>?');" style="display:inline">
                                    <input type="hidden" name="action" value="del_prof">
                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="btn-sm btn-danger">🗑 Elimina</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- ══ TAB RICHIESTE ══════════════════════════════════════ -->
        <div class="tab-panel <?= $activeTab==='richieste'?'active':'' ?>" id="tab-richieste">
            <div class="card">
                <h3>📬 Richieste di Registrazione Scuola</h3>
                <?php if (empty($richieste)): ?>
                    <p style="color:#888;">Nessuna richiesta ricevuta.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead><tr><th>Scuola</th><th>Admin</th><th>Classi</th><th>Data</th><th>Stato</th><th>Azioni</th></tr></thead>
                    <tbody>
                        <?php foreach ($richieste as $req):
                            $classiReq    = json_decode($req['classi_json'], true);
                            $nClassiReq   = count($classiReq);
                            $nStudentiReq = array_sum(array_column($classiReq, 'n_studenti'));
                            $statoColore  = match($req['stato']) { 'approvata'=>'#166534','rifiutata'=>'#991b1b',default=>'#92400e' };
                            $statoLabel   = match($req['stato']) { 'approvata'=>'✅ Approvata','rifiutata'=>'❌ Rifiutata',default=>'⏳ In attesa' };
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($req['nome']) ?></strong><br><span style="font-size:12px;color:#888;"><?= htmlspecialchars($req['citta']) ?></span></td>
                            <td><code><?= htmlspecialchars($req['admin_username']) ?></code></td>
                            <td><span class="stat-pill"><?= $nClassiReq ?> classi</span> <span class="stat-pill"><?= $nStudentiReq ?> stud.</span></td>
                            <td style="font-size:13px;"><?= date('d/m/Y H:i', strtotime($req['creato_il'])) ?></td>
                            <td><span style="font-weight:700;color:<?= $statoColore ?>"><?= $statoLabel ?></span></td>
                            <td>
                                <?php if ($req['stato'] === 'in_attesa'): ?>
                                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                                    <button class="btn-sm" style="background:#166534;" onclick="gestisciRichiesta(<?= $req['id'] ?>, 'approva')">✅ Approva</button>
                                    <button class="btn-sm btn-danger" onclick="gestisciRichiesta(<?= $req['id'] ?>, 'rifiuta')">❌ Rifiuta</button>
                                </div>
                                <?php else: ?>
                                    <span style="font-size:12px;color:#aaa;"><?= date('d/m/Y', strtotime($req['gestita_il'])) ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- MODAL MODIFICA SCUOLA -->
    <div class="modal-bg" id="modalEditScuola">
        <div class="modal">
            <h4>✏️ Modifica Scuola</h4>
            <form method="POST">
                <input type="hidden" name="action" value="update_scuola">
                <input type="hidden" name="id" id="editScuolaId">
                <label>Nome</label>
                <input type="text" name="nome" id="editScuolaNome" required>
                <label>Città</label>
                <input type="text" name="citta" id="editScuolaCitta" required>
                <label>Logo (nome file)</label>
                <input type="text" name="logo" id="editScuolaLogo">
                <label>Anno scolastico</label>
                <input type="text" name="anno_scolastico" id="editScuolaAnno" pattern="\d{4}-\d{4}" required>
                <div class="form-row" style="margin-top:6px;">
                    <button type="submit">Salva</button>
                    <button type="button" onclick="closeModal('modalEditScuola')" style="background:#888;">Annulla</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL RESET PASSWORD -->
    <div class="modal-bg" id="modalResetPass">
        <div class="modal">
            <h4>🔑 Reset Password</h4>
            <p id="modalResetName" style="font-size:14px; color:#666; margin-bottom:14px;"></p>
            <form method="POST" id="formResetPass">
                <input type="hidden" name="action" id="resetPassAction">
                <input type="hidden" name="id"     id="resetPassId">
                <input type="password" name="password" placeholder="Nuova password *" required>
                <div class="form-row">
                    <button type="submit">Salva</button>
                    <button type="button" onclick="closeModal('modalResetPass')" style="background:#888;">Annulla</button>
                </div>
            </form>
        </div>
    </div>

    <div id="contatti">
        <h2>Sistema</h2>
        <h4>Pannello Super Admin — accesso riservato</h4>
    </div>

    <script>
        function showTab(name, btn) {
            document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.getElementById('tab-' + name).classList.add('active');
            if (btn) btn.classList.add('active');
        }

        function openEditScuola(s) {
            document.getElementById('editScuolaId').value    = s.id;
            document.getElementById('editScuolaNome').value  = s.nome;
            document.getElementById('editScuolaCitta').value = s.citta;
            document.getElementById('editScuolaLogo').value  = s.logo;
            document.getElementById('editScuolaAnno').value  = s.anno_scolastico;
            document.getElementById('modalEditScuola').classList.add('open');
        }

        function openResetPass(tipo, id, username) {
            document.getElementById('resetPassAction').value = tipo === 'admin' ? 'reset_admin_pass' : 'reset_prof_pass';
            document.getElementById('resetPassId').value     = id;
            document.getElementById('modalResetName').textContent = (tipo === 'admin' ? 'Admin' : 'Prof') + ': ' + username;
            document.getElementById('modalResetPass').classList.add('open');
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('open');
        }

        async function gestisciRichiesta(id, azione) {
            const label = azione === 'approva' ? 'approvare' : 'rifiutare';
            if (!confirm('Sei sicuro di voler ' + label + ' questa richiesta?')) return;
            const fd = new FormData();
            fd.append('id', id);
            fd.append('azione', azione);
            const res  = await fetch('approva_scuola.php', { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                location.reload();
            } else {
                alert('Errore: ' + data.error);
            }
        }

        ['modalEditScuola','modalResetPass'].forEach(id => {
            document.getElementById(id).addEventListener('click', function(e) {
                if (e.target === this) closeModal(id);
            });
        });
    </script>

</body>
</html>
