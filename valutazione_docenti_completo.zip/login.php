<?php
session_start();

if (isset($_SESSION['user_id'])) {
    $dest = match($_SESSION['ruolo']) {
        'prof'       => 'dashboard_prof.php',
        'admin'      => 'dashboard_admin.php',
        'superadmin' => 'dashboard_superadmin.php',
        default      => 'valutazione.php',
    };
    header('Location: ' . $dest);
    exit;
}

$error  = '';
$scuole = [];

try {
    $pdoTmp = new PDO(
        "mysql:host=localhost;dbname=my_valutazionedocentimajo;charset=utf8mb4",
        'root', '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $scuole = $pdoTmp->query("SELECT id, nome, citta FROM scuola ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* silenzioso */ }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $ruolo    = $_POST['ruolo']    ?? '';
    $idScuola = (int)($_POST['scuola'] ?? 0);

    $superadminLogin = ($ruolo === 'superadmin');
    if (empty($username) || empty($password) || empty($ruolo) || (!$superadminLogin && $idScuola <= 0)) {
        $error = 'Compila tutti i campi.';
    } else {
        try {
            $pdo = new PDO(
                "mysql:host=localhost;dbname=my_valutazionedocentimajo;charset=utf8mb4",
                'root', '',
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            if ($ruolo === 'studente') {
                // Studenti: confronto in chiaro (password NON hashata)
                $stmt = $pdo->prepare(
                    "SELECT id, username, classe, IsUsed
                     FROM studenti
                     WHERE username = ? AND password = ? AND scuola = ?
                     LIMIT 1"
                );
                $stmt->execute([$username, $password, $idScuola]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']  = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['ruolo']    = 'studente';
                    $_SESSION['classe']   = $user['classe'];
                    $_SESSION['is_used']  = $user['IsUsed'];
                    $_SESSION['scuola']   = $idScuola;
                    header('Location: valutazione.php');
                    exit;
                } else {
                    $error = 'Username o password non corretti.';
                }

            } elseif ($ruolo === 'prof') {
                // Prof: recupera hash e verifica con password_verify
                $stmt = $pdo->prepare(
                    "SELECT id, nome, cognome, mail, username, password
                     FROM prof
                     WHERE username = ? AND scuola = ?
                     LIMIT 1"
                );
                $stmt->execute([$username, $idScuola]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']  = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['ruolo']    = 'prof';
                    $_SESSION['nome']     = $user['nome'] . ' ' . $user['cognome'];
                    $_SESSION['mail']     = $user['mail'];
                    $_SESSION['scuola']   = $idScuola;
                    header('Location: dashboard_prof.php');
                    exit;
                } else {
                    $error = 'Username o password non corretti.';
                }

            } elseif ($ruolo === 'admin') {
                // Admin: recupera hash e verifica con password_verify
                $stmt = $pdo->prepare(
                    "SELECT id, username, password
                     FROM amministratori
                     WHERE username = ? AND scuola = ?
                     LIMIT 1"
                );
                $stmt->execute([$username, $idScuola]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']  = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['ruolo']    = 'admin';
                    $_SESSION['scuola']   = $idScuola;
                    header('Location: dashboard_admin.php');
                    exit;
                } else {
                    $error = 'Username o password non corretti.';
                }

            } elseif ($ruolo === 'superadmin') {
                // Superadmin: non è legato a una scuola
                $stmt = $pdo->prepare(
                    "SELECT id, username, password FROM super_admin WHERE username = ? LIMIT 1"
                );
                $stmt->execute([$username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user && password_verify($password, $user['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']  = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['ruolo']    = 'superadmin';
                    $_SESSION['scuola']   = 0; // nessuna scuola specifica
                    header('Location: dashboard_superadmin.php');
                    exit;
                } else {
                    $error = 'Username o password non corretti.';
                }

            } else {
                $error = 'Ruolo non valido.';
            }

        } catch (PDOException $e) {
            $error = 'Errore di connessione al database.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login – Valutazione Docenti</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="styles_unified.css">
    <style>
        #scuola-badge {
            display: none;
            text-align: center;
            font-size: 13px;
            font-weight: 600;
            color: var(--blu);
            background: var(--blu-light);
            border: 1px solid #c8d4ff;
            border-radius: 100px;
            padding: 5px 16px;
            margin-bottom: 14px;
        }
    </style>
</head>
<body>

    <header class="page-hero">
        <h1>Valutazione Docenti</h1>
        <h2>Accedi al tuo istituto</h2>
    </header>

    <div id="login">
        <div id="errore"><?php if ($error) echo htmlspecialchars($error); ?></div>

        <form method="POST" action="login.php">

            <label for="scuola">Istituto scolastico</label>
            <select name="scuola" id="scuola" required onchange="aggiornaScuola(this)">
                <option value="">-- seleziona la scuola --</option>
                <?php foreach ($scuole as $s): ?>
                    <option value="<?= $s['id'] ?>"
                        <?= ((int)($_POST['scuola'] ?? 0) === (int)$s['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['nome']) ?> – <?= htmlspecialchars($s['citta']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <div id="scuola-badge">🏫 <span id="scuola-nome"></span></div>

            <label for="ruolo">Ruolo</label>
            <select name="ruolo" id="ruolo" required>
                <option value="">-- seleziona --</option>
                <option value="studente" <?= ($_POST['ruolo'] ?? '') === 'studente' ? 'selected' : '' ?>>Studente</option>
                <option value="prof"     <?= ($_POST['ruolo'] ?? '') === 'prof'     ? 'selected' : '' ?>>Professore</option>
                <option value="admin"      <?= ($_POST['ruolo'] ?? '') === 'admin'      ? 'selected' : '' ?>>Amministratore</option>
                <option value="superadmin" <?= ($_POST['ruolo'] ?? '') === 'superadmin' ? 'selected' : '' ?>>Super Admin</option>
            </select>

            <label for="username">Username</label>
            <input type="text" name="username" id="username"
                   placeholder="Inserisci username"
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                   autocomplete="username">

            <label for="password">Password</label>
            <input type="password" name="password" id="password"
                   placeholder="Inserisci password"
                   autocomplete="current-password">

            <button type="submit">Entra</button>
        </form>
        <p style="font-size:13px; color:#888; text-align:center; margin-top:14px;">
            <a href="reset_password.php" style="color:var(--blu);">🔐 Password dimenticata?</a>
        </p>
    </div>

    <div id="contatti">
        <h2>Contatti</h2>
        <h4>Per assistenza contatta l'amministratore del sistema.</h4>
    </div>

    <script>
        function aggiornaScuola(sel) {
            const badge = document.getElementById('scuola-badge');
            const nome  = document.getElementById('scuola-nome');
            const testo = sel.options[sel.selectedIndex]?.text || '';
            if (sel.value) {
                badge.style.display = 'block';
                nome.textContent = testo;
            } else {
                badge.style.display = 'none';
            }
        }
        aggiornaScuola(document.getElementById('scuola'));

        // Nascondi selezione scuola per superadmin
        document.getElementById('ruolo').addEventListener('change', function() {
            const scuolaWrap = document.getElementById('scuola').closest('label') || document.getElementById('scuola').previousElementSibling;
            const isSuperadmin = this.value === 'superadmin';
            document.getElementById('scuola').closest('div, p, label')?.style;
            // Nascondi label + select scuola e gestisci required
            const scuolaLabel = document.querySelector('label[for="scuola"]');
            const scuolaSelect = document.getElementById('scuola');
            const scuolaBadge = document.getElementById('scuola-badge');
            if (scuolaLabel)  scuolaLabel.style.display  = isSuperadmin ? 'none' : '';
            if (scuolaSelect) {
                scuolaSelect.style.display = isSuperadmin ? 'none' : '';
                scuolaSelect.required      = !isSuperadmin;
            }
            if (scuolaBadge)  scuolaBadge.style.display   = 'none';
            if (!isSuperadmin && scuolaSelect.value) aggiornaScuola(scuolaSelect);
        });
    </script>

</body>
</html>
