<?php
// registra_prof.php  –  endpoint JSON chiamato da registra_prof.html

$host   = 'localhost';
$dbname = 'my_valutazionedocentimajo';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Connessione al database fallita.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Dati non validi.']);
    exit;
}

$username = trim($data['username'] ?? '');
$nome     = trim($data['nome']     ?? '');
$password = trim($data['password'] ?? '');
$codice   = trim($data['codice']   ?? '');
$classi   = $data['classi']        ?? [];
$idScuola = (int)($data['scuola']  ?? 0);

// Validazione campi obbligatori
if (!$username || !$nome || !$password || !$codice || $idScuola <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Campi obbligatori mancanti.']);
    exit;
}

if (strlen($password) > 10) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Password troppo lunga (max 10 caratteri).']);
    exit;
}

// Verifica scuola e codice di registrazione
$chkScuola = $pdo->prepare(
    "SELECT id, codice_registrazione FROM scuola WHERE id = ? LIMIT 1"
);
$chkScuola->execute([$idScuola]);
$scuola = $chkScuola->fetch(PDO::FETCH_ASSOC);

if (!$scuola) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Scuola non valida.']);
    exit;
}

// Verifica codice con password_verify (il codice nel DB è hashato con bcrypt)
if (!password_verify($codice, $scuola['codice_registrazione'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Chiave di registrazione non corretta.']);
    exit;
}

// Username unico per scuola
$chkUser = $pdo->prepare("SELECT id FROM prof WHERE username = ? AND scuola = ?");
$chkUser->execute([$username, $idScuola]);
if ($chkUser->fetch()) {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'Username già in uso in questa scuola.']);
    exit;
}

$parti      = explode(' ', $nome, 2);
$nomeDB     = substr($parti[0], 0, 100);
$cognome    = isset($parti[1]) ? substr($parti[1], 0, 100) : '';
$passHash   = password_hash($password, PASSWORD_BCRYPT);

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        "INSERT INTO prof (nome, cognome, mail, username, password, scuola)
         VALUES (?, ?, '', ?, ?, ?)"
    );
    $stmt->execute([$nomeDB, $cognome, $username, $passHash, $idScuola]);
    $idProf = $pdo->lastInsertId();

    if (!empty($classi)) {
        $chkClasse = $pdo->prepare("SELECT classe FROM classi WHERE classe = ? AND scuola = ?");
        $insClasse  = $pdo->prepare("INSERT INTO insegna (id, classe, scuola) VALUES (?, ?, ?)");

        foreach ($classi as $classe) {
            $classe = trim($classe);
            if (empty($classe)) continue;
            $chkClasse->execute([$classe, $idScuola]);
            if ($chkClasse->fetch()) {
                $insClasse->execute([$idProf, $classe, $idScuola]);
            }
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'idProf' => (int)$idProf]);

} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Errore durante il salvataggio.']);
}
