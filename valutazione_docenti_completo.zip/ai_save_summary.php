<?php
// ai_save_summary.php  –  salva nel DB il riassunto generato dal browser
// Chiamato dopo che il Worker Cloudflare ha restituito il riassunto

header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['ruolo'] !== 'prof') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accesso negato.']);
    exit;
}

$idProf   = (int)$_SESSION['user_id'];
$idScuola = (int)$_SESSION['scuola'];

$data           = json_decode(file_get_contents('php://input'), true);
$classe         = trim($data['classe']         ?? '');
$riassunto      = trim($data['riassunto']      ?? '');
$nFeedback      = (int)($data['n_feedback']    ?? 0);
$annoScolastico = trim($data['anno_scolastico'] ?? '');

if (!$classe || !$riassunto || !$annoScolastico) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Dati mancanti.']);
    exit;
}

require_once 'db.php';
require_once 'crypto.php';

// Verifica che il prof insegni in questa classe
$chk = $pdo->prepare("SELECT 1 FROM insegna WHERE id = ? AND classe = ? AND scuola = ?");
$chk->execute([$idProf, $classe, $idScuola]);
if (!$chk->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Classe non autorizzata.']);
    exit;
}

try {
    $pdo->prepare(
        "INSERT INTO riassunti_ai (idProf, classe, scuola, riassunto, n_feedback, anno_scolastico)
         VALUES (?, ?, ?, ?, ?, ?)"
    )->execute([$idProf, $classe, $idScuola, encrypt($riassunto), $nFeedback, $annoScolastico]);

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    // Unique constraint: già salvato (race condition)
    if (str_contains($e->getMessage(), 'Duplicate')) {
        echo json_encode(['success' => true, 'already_exists' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Errore salvataggio nel database.']);
    }
}
